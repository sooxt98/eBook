class MySubClass(object):
    pass
