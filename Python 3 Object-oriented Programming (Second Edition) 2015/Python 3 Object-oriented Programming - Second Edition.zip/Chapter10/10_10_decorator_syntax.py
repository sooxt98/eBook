@log_calls
def test1(a,b,c):
    print("\ttest1 called")
