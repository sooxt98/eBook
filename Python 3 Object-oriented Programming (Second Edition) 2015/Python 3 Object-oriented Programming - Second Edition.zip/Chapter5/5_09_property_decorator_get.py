class Foo:
    @property
    def foo(self):
        return "bar"
