def get_pages(*links):
    for link in links:
        #download the link with urllib
        print(link)

