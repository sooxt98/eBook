file = open('filename')
print(file.read())
