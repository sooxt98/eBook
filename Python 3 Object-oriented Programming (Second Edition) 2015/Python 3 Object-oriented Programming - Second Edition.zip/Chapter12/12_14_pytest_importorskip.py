import py.test

py.test.importorskip("postgresql")

def test_connect():
    pass

def test_query():
    pass
