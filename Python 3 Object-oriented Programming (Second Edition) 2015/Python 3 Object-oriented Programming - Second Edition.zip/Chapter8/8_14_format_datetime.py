import datetime
print("{0:%Y-%m-%d %I:%M%p }".format(
    datetime.datetime.now()))

