input_strings = ['1', '5', '28', '131', '3']

output_integers = [int(num) for num in input_strings]

print(output_integers)
