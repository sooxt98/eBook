from collections import Counter
def letter_frequency(sentence):
    return Counter(sentence)
