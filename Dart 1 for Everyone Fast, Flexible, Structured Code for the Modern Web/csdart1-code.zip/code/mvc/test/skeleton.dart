library skeleton_snippet_test;

import 'package:unittest/unittest.dart';

import '../public/scripts/skel.dart' as Skeleton;

run() {
  group("[skeleton]", (){
    test('the skeleton app returns OK', (){
      expect(Skeleton.main, returnsNormally);
    });
  });
}
