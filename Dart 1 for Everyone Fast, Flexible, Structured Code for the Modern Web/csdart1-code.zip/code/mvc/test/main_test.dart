library main_test;

import 'package:unittest/unittest.dart';
import 'dart:html';
import 'dart:async';

import '../web/scripts/comics.dart' as Main;

final String URL_ROOT = 'http://localhost:31337/widgets';

run() {
  group("[main]", (){
    var el = new Element.html('<ul id="comics-list">');

    setUp((){
      document.body
        ..append(el)
        ..append(new Element.html('<div id="add-comic">'));

      var doc = '{"id":"42", "title": "Sandman", "author":"Neil Gaiman"}';
      return HttpRequest.
        request(URL_ROOT, method: 'post', sendData: doc);
    });

    tearDown((){
      document.body.innerHtml = '';
    });

    test('the app returns OK', (){
      expect(Main.main, returnsNormally);
    });

    test('populates the list', (){
      Main.main();
      expect(el.innerHtml, contains('Sandman'));
    });

    group('adding', (){
      setUp((){
        Main.main();
        query('#add-comic').click();
        (query('input[name=title]') as InputElement).value = 'Superman';
        query('input[value="Create!"]').click();

        var completer = new Completer();
        new Timer(
          new Duration(milliseconds: 200),
          completer.complete
        );
        return completer.future;
      });

      test('populates the list', (){
        expect(el.innerHtml, contains('Superman'));
      });
    });
  });
}
