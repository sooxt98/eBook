library mvc_tests;

import 'main_test.dart' as Main;

main () {
  Main.run();
}
