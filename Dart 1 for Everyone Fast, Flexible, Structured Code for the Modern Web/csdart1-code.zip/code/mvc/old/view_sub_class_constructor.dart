class Comics extends HipsterView {
  Comics([collection, model, el]):
    super(collection:collection, model:model, el:el);
}
