class ComicsCollection implements Collection {
  //  ...
  void fetch() {
    var req = new HttpRequest();
    req.onLoad.listen((event) {
      var request = event.target,
          list = JSON.decode(request.responseText);
      _handleOnLoad(list);
    });
    // verb, resource, boolean async
    req.open('get', url, true);
    req.send();
  }
}
