class ComicsCollection implements Collection {
  CollectionEvents on;
  List models;
  // Constructor method
  ComicsCollection() {
    on = new CollectionEvents();
    models = [];
  }
}
