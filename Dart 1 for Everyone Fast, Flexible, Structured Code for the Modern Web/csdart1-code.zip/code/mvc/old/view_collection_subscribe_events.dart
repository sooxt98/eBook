class ComicsView {
  // ...
  _subscribeEvents() {
    if (collection == null) return;

    collection.onLoad.listen((event) { render(); });
    collection.onAdd.listen((event) { render(); });
  }
}
