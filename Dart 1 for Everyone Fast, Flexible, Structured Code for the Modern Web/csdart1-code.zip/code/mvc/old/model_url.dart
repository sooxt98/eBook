class ComicBook {
  // ...
  get url() => isSaved() ?
    urlRoot : "$urlRoot/${attributes['id']}";

  get urlRoot() => 'comics';

  isSaved() => attributes['id'] == null;
}
