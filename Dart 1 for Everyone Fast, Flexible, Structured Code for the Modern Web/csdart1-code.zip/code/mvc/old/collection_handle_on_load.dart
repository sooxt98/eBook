class ComicsCollection implements Collection {
  //  ...
  _handleOnLoad(list) {
    list.forEach((attrs) {
      var new_model = new ComicBook(attrs);
      new_model.collection = this;
      models.add(new_model);
    });

    onLoad.dispatch(new CollectionEvent('load', this));
  }
}
