class ComicBook {
  // ...
  operator [](attr) => attributes[attr];
}
