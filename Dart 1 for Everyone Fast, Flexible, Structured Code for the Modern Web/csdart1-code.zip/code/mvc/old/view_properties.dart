class ComicsView {
  var collection, model;
  Element el;
}
