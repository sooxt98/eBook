class ComicsView {
  // ...
  ComicsView([this.el, this.model, this.collection]);
}
