#import('dart:html');
#import('dart:json');
main() {
  var my_comics_collection = new Comics()
    , comics_view = new ComicsView(
        el:'#comics-list',
        collection: my_comics_collection
      );
  my_comics_collection.fetch();
}
