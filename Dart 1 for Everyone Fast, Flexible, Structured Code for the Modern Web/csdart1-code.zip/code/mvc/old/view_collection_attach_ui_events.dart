class ComicsViews {
  // ...
  ComicsView([this.el, this.model, this.collection]) {
    _subscribeEvents();
    _attachUiHandlers();
  }
  // ...
  _attachUiHandlers() {
    attach_handler(el, 'click .delete', delete);
  }
  delete(event) {
    var id = event.target.parent.id;
    collection[id].delete(callback:(_) {
      event.target.parent.remove();
    });
  }
}
