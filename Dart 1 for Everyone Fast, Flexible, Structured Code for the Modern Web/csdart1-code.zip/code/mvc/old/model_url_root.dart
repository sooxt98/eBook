class ComicBook extends HipsterModel {
  // ...
  get urlRoot() => 'comics';
}
