class HipsterCollection implements Collection {
  // ...
  abstract HipsterModel modelMaker(attrs);
  abstract String get url();
}
