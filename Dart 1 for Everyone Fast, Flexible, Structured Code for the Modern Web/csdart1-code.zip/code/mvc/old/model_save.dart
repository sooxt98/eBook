#import('dart:json');
class ComicBook {
  // ...
  save([callback]) {
    var req = new HttpRequest()
      , json = JSON.stringify(attributes);
    req.onLoad.listen((load_event) {
      var request = load_event.target;
      attributes = JSON.parse(request.responseText);
      var model_event = new ModelEvent('save', this);
      on.save.dispatch(model_event);
      if (callback != null) callback(model_event);
    });
    req.open('post', url, true);
    req.setRequestHeader('Content-type', 'application/json');
    req.send(json);
  }
}
