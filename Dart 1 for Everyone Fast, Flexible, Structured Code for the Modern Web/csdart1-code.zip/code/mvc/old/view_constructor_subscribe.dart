class ComicsViews {
  // ...
  ComicsView([this.el, this.model, this.collection]) {
    _subscribeEvents();
  }
}
