class ComicBook {
  Map attributes;
  ModelEvents on;
  HipsterCollection collection;

  ComicBook(this.attributes) {
    on = new ModelEvents();
  }
}
