class ComicsCollection implements Collection {
  //  ...
  void forEach(fn) {
    models.forEach(fn);
  }

  int get length() {
    return models.length;
  }

  operator [](id) {
    var ret;
    forEach((model) {
      if (model['id'] == id) ret = model;
    });
    return ret;
  }
}
