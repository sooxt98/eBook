library main;

import 'dart:html';
import 'dart:convert';
import 'dart:collection';
main() {
  var comics_view, comics_collection;


  comics_collection = new ComicsCollection(
    onChange: ()=> comics_view.render()
  );
  comics_view = new ComicsView(
    el: document.query('#comics-list'),
    collection: comics_collection
  );
  comics_collection.fetch();

  new CreateComicView(
    el: document.query('#add-comic'),
    collection: comics_collection
  );
}

class ComicsCollection extends IterableBase {
  // ...

  List models = [];
  Iterator get iterator => models.iterator;

  var onChange = (){};

  // Constructor method
  ComicsCollection({this.onChange});

  String get url => 'http://localhost:31337/widgets';

  void fetch() {
    var req = new HttpRequest();
    req.onLoad.listen((event) {
      var list = JSON.decode(req.responseText);
      _handleOnLoad(list);
    });
    req.open('get', url);
    req.send();
  }

  _handleOnLoad(list) {
    list.forEach((attrs) {
      var new_model = new ComicBook(attrs, collection: this);
      models.add(new_model);
      onChange();
    });
  }

  create(attrs) {
    var new_model = new ComicBook(attrs, collection: this);
    new_model.save((event) {
      models.add(new_model);
      onChange();
    });
  }
  // ...
}

class ComicBook {
  Map attributes;
  ComicsCollection collection;

  ComicBook(this.attributes, {this.collection});

  operator [](attr) => attributes[attr];

  get id => attributes['id'];
  String get url => isSaved ?
    "$urlRoot/$id" : urlRoot;

  String get urlRoot => (collection == null) ?
    "" : collection.url;

  bool get isSaved => id != null;

  save([callback]) {
    var req = new HttpRequest(),
        method = isSaved ? 'PUT' : 'POST',
        json = JSON.encode(attributes);
    req.onLoad.listen((load_event) {
      var request = load_event.target;
      attributes = JSON.decode(request.responseText);
      if (callback != null) callback(this);
    });
    req.open(method, url);
    req.setRequestHeader('Content-type', 'application/json');
    req.send(json);
  }

  delete([callback]) {
    var req = new HttpRequest();
    req.onLoad.listen((load_event) {
      var request = load_event.target;
      if (callback != null) callback(this);
    });
    req.open('delete', url);
    req.send();
  }
}

class CreateComicView {
  var el, model, collection;
  Element form;

  CreateComicView({this.el, this.model, this.collection}) {
    el.onClick.listen((event) => toggleForm());
    attachForm();
  }

  toggleForm() {
    if (form.style.display == 'none') {
      form.style.display = 'block';
    }
    else {
      form.style.display = 'none';
    }
  }

  attachForm() {
    form = new Element.html("<div>${template}</div>");
    form.style.display = 'none';
    el.parent.children.add(form);
    InputElement titleInput = form.query('input[name=title]'),
                 authorInput = form.query('input[name=author]');
    // handle create form submission
    form.query('form').onSubmit.listen((event) {
      collection.create({
        'title': titleInput.value,
        'author': authorInput.value
      });
      form.
        queryAll('input[type=text]').
        forEach((InputElement input) => input.value = '');
      toggleForm();
      event.preventDefault();
    });

    // handle clicks on the Cancel link
    form.query('a').onClick.listen((event) {
      toggleForm();
      event.preventDefault();
    });
  }

  get template => """
      <form action="comics" id="new-comic-form">
        <p>
          <label>Title<br>
            <input type="text" name="title">
          </label>
        </p>

        <p>
          <label>Author<br>
            <input type="text" name="author">
          </label>
        </p>

        <p>
          <input type="submit" value="Create!"><br>
          <a href="#">Cancel</a>
        </p>
      </form>
    """;
}

class ComicsView {
  var el, model, collection;
  ComicsView({this.el, this.model, this.collection});

  // ...
  render() { el.innerHtml = template(); }

  template() =>
    collection.map(_singleComicBookTemplate).join();

  _singleComicBookTemplate(comic) => """
      <li id="${comic['id']}">
        ${comic['title']}
        (${comic['author']})
        <a href="#" class="delete">[delete]</a>
      </li>""";
}
