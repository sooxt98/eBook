#import('dart:html');
main() {
  WebSocket ws = new WebSocket("ws://localhost:3000/");

  // After open, send a message to the server
  ws.
    on.
    open.
    add((event) {
      bool ret = ws.send("Hello");
      print("Sent: $ret");
    });

  // Handle messages from the server, printing to the console
  ws.
    on.
    message.
    add((event) {
      print("Got an event: $event");
      print("The data in the event is: ${event.data}");
    });

  // Print message to the console on WS error
  ws.
    on.
    error.
    add((event) {
      print("whoa: $event");
    });
}


/*

var ws = new WebSocket("ws://localhost:3000");
ws.onopen = function(e){ console.log("Connected..."); }
ws.onclose = function(e){ console.log("Disconnected."); }
ws.onerror = function(e){ console.log("ERROR: ${e.data}"); }
ws.onmessage = function(e){ console.log("Message: ${e.data}"); }

ws.send("howdy!")

*/
