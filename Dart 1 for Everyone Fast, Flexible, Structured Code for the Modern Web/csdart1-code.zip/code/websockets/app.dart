#import('dart:io');
#import('dart:html');

startServer(String basePath) {
  var server = new HttpServer();
  server.listen('127.0.0.1', 8080);
  server.onRequest = (HttpRequest request, HttpResponse response) {
    var path = request.path == '/' ? '/index.html' : request.path;
    var file = new File('${basePath}${path}');
    file.exists((found) {
      if (found) {
        file.openInputStream().pipe(response.outputStream);
      } else {
        response.statusCode = HttpStatus.NOT_FOUND;
        response.outputStream.close();
      }
    });
  };
}

main() {
  // Compute base path for the request based on the location of the
  // script and then start the server.
  File script = new File(new Options().script);
  script.directory((Directory d) {
    startServer(d.path);
  });
}
