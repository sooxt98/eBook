import 'package:unittest/unittest.dart';
import 'dart:html';
import 'dart:async';

import 'your_first_dart_app/test/test.dart' as YourFirstApp;
import 'primitives/test.dart' as Primitives;
import 'functional_programming/test.dart' as FunctionalProgramming;
import 'dom/test.dart' as Dom;

import 'javascript/test/compiling_javascript_test.dart' as Compiling;
import 'javascript/test/calling_javascript_test.dart' as Calling;

import 'mvc/test/test.dart' as Mvc;
import 'classes/test.dart' as Classes;
import 'events/test.dart' as DartEvents;

import 'mvc_library/test/test.dart' as MvcLibrary;
import 'libraries/tests/test.dart' as Libraries;

import 'varying_the_behavior/test/test.dart' as VaryBehavior;
// testing

// no_more_callback_hell
import 'isolates/test/test.dart' as Isolates;
import 'html5/test/test.dart' as Html5;

// import 'package:unittest/html_enhanced_config.dart';
main () {
  // useHtmlEnhancedConfiguration();

  YourFirstApp.main();
  Primitives.main();
  FunctionalProgramming.main();
  Dom.main();

  Compiling.main();
  Calling.main();

  Mvc.main();
  Classes.main();
  DartEvents.main();
  MvcLibrary.main();
  Libraries.main();

  VaryBehavior.main();

  Isolates.main();
  Html5.main();

  pollForDone(testCases);
}

pollForDone(List tests) {
  if (tests.every((t)=> t.isComplete)) {
    window.postMessage('done', window.location.href);
    return;
  }

  var wait = new Duration(milliseconds: 100);
  new Timer(wait, ()=> pollForDone(tests));
}
