library html5_test;

import 'package:unittest/unittest.dart';
import 'dart:html';

import '../web/main.dart' as Canvas;

main () {
  group("[canvas]", (){
    var canvas;

    setUp((){
      canvas = new CanvasElement();
      document.body.append(canvas);
    });

    tearDown(()=> canvas.remove());

    test("code runs", (){
      expect(Canvas.main, returnsNormally);
    });

    test("player is drawn", (){
      Canvas.main();
      var context = canvas.getContext('2d');
      expect(context.isPointInPath(30, 30), isTrue);
    });
  });
}
