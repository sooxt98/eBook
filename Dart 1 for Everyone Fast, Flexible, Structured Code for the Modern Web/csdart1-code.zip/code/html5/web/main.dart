import 'dart:html';

CanvasRenderingContext2D context;

main() {
  CanvasElement canvas = document.query('canvas');
  context = canvas.getContext('2d');

  var me = new Player();
  draw(me);

  document.
    onKeyDown.
    listen((event) {
      String direction;

      // Listen for arrow keys
      if (event.keyCode == 37) direction = 'left';
      if (event.keyCode == 38) direction = 'up';
      if (event.keyCode == 39) direction = 'right';
      if (event.keyCode == 40) direction = 'down';
      if (direction != null) {
        event.preventDefault();
        me.move(direction);
        draw(me);
      }
    });
}

draw(Player player) {
  int width = context.canvas.width,
      height = context.canvas.height;

  context.beginPath();

  // clear drawing area
  context.clearRect(0,0,width,height);
  context.fillStyle = '#ffffff';
  context.strokeStyle = '#000000';
  context.fillRect(0,0,width,height);

  // draw me and fill me in
  context.rect(
    player.x,
    player.y,
    player.width,
    player.height
  );

  context.fillStyle = 'red';
  context.fill();

  context.stroke();

  context.closePath();
}

class Player {
  int x, y;
  int width = 20, height = 20;
  Player() {
    x = width~/2;
    y = height~/2;
  }
  move(String dir) {
    if (dir == 'left') x-= 10;
    if (dir == 'right') x+= 10;
    if (dir == 'up') y-= 10;
    if (dir == 'down') y+= 10;
  }
}
