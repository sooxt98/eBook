library main_test;

import 'package:unittest/unittest.dart';
import 'dart:html';
import 'dart:async';

import 'package:plummbur_kruk/kruk.dart';

import '../web/scripts/comics.dart' as Main;

run() {
  group("[main]", (){
    var el;

    setUp((){
      document.head.append(new BaseElement()..href = Kruk.SERVER_ROOT);;

      el = document.body.append(new Element.html('<ul id=comics-list>'));

      var doc = '{"id":"42", "title": "Sandman", "author":"Neil Gaiman"}';
      return Future.wait([
        Kruk.create(doc),
        Kruk.alias('/widgets', as: '/comics')
      ]);

    });

    tearDown((){
      el.remove();
      return Kruk.deleteAll();
    });

    test('the app returns OK', (){
      expect(Main.main, returnsNormally);
    });

    test('populates the list', (){
      Main.main();
      new Timer(new Duration(milliseconds: 10),
        expectAsync(() {
          expect(el.innerHtml, contains('Sandman'));
        })
      );
    });
  });
}
