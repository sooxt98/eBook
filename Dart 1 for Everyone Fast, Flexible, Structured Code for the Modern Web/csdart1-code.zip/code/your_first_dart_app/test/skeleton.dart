library skeleton_snippet_test;

import 'package:unittest/unittest.dart';

import '../web/scripts/skel.dart' as Skeleton;

run() {
  group("[skeleton]", (){
    test('the skeleton app returns OK', (){
      expect(Skeleton.main, returnsNormally);
    });
  });
}
