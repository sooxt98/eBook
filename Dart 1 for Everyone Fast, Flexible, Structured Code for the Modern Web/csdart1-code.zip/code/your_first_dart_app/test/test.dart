library your_first_app_tests;

import 'skeleton.dart' as Skeleton;
import 'main_test.dart' as Main;

main () {
  Skeleton.run();
  Main.run();
}
