#import("dart:html");

// #import("https://raw.github.com/eee-c/hipster-mvc/master/HipsterRouter.dart");
#import("/home/cstrom/repos/hipster-mvc/HipsterRouter.dart");

// #import("https://raw.github.com/eee-c/hipster-mvc/master/HipsterHistory.dart");
#import("/home/cstrom/repos/hipster-mvc/HipsterHistory.dart");

main() {
  HipsterRouter app = new MyRouter();

  app.
    on['route:page'].
    add((num) {
      print("Routed to page: $num");
    });

  HipsterHistory.startHistory();
}

class MyRouter extends HipsterRouter {
  List get routes() =>
    [
      ['page/:num', pageNum, 'page']
    ];

  pageNum(num) {
    var el = document.query('body');
    el.innerHTML = _pageNumTemplate(num);
  }

  _pageNumTemplate(num) {
    return """
<h1>$num</h1>
<p>Now we're on page <b>$num</b>.</p>""";
  }
}
