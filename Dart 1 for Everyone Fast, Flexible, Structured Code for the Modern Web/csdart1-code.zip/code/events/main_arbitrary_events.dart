import 'dart:html';

class MyCustomEvent implements Event {
  String _type;
  MyCustomEvent(this._type);

  String get type => _type;
  void set type(new_type) {
    _type = new_type;
  }
}

main () {
  Element el = document.query('#status');
  Event green_event = new Event('green');

  el.
    on['status'].
    add((event) {
      print("event received: ${event.type}");
      el.style.color = event.type;
    });

  el.
    on['click'].
    add((event) {
      el.style.textDecoration = 'underline';

      el.
       on['status'].
       dispatch(green_event);
    });

  // window.setTimeout(() {

  el.
    on['status'].
    dispatch(green_event);

  //   print("event sent: ${my_event.type}");
  // }, 500);


  print(el);
}
