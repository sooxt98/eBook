library http_request_snippet;

import 'dart:html';
import 'dart:convert';
import 'package:unittest/unittest.dart';
import 'package:plummbur_kruk/kruk.dart';

graphicNovelsTemplate(list) => "asdf $list asdf";

run() {
  group("[http_request]", (){
    Element container;

    setUp((){
      var doc = '{"id":"42", "title": "Sandman", "author":"Neil Gaiman"}';
      return Kruk.create(doc);
    });

    tearDown((){
      container.remove();
      return Kruk.deleteAll();
    });

    test('load event', (){
      container = new DivElement();
      document.body.append(container);

      var req = new HttpRequest();

      req.onLoad.listen((event) {
        var list = JSON.decode(req.responseText);
        container.innerHtml = graphicNovelsTemplate(list);
      });

      req
        ..open('GET', Kruk.widgets_url, async: false)
        ..send();

      expect(container.innerHtml, contains('Sandman'));
    });
  });
}
