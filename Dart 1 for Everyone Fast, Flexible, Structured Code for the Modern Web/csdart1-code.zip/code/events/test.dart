library events_tests;

import 'simple.dart' as Simple;
import 'http_request.dart' as HttpRequest;
import 'collection_events.dart' as CollectionEvents;
import 'collection_event_target.dart' as CollectionEventTarget;

main () {
  Simple.run();
  HttpRequest.run();
  CollectionEvents.run();
  CollectionEventTarget.run();
}
