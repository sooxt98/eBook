library collection_event_target_snippet;

import 'dart:async';
import 'dart:collection';
import 'package:unittest/unittest.dart';

class ComicsView {
  // called by the constructor
  _subscribeEvents() {
    if (collection == null) return;
    collection.onLoad.listen((event)=> render());
    collection.onAdd.listen((event)=> render());
  }

  var collection;

  render() {
    // render the list to the page
  }
}

class ComicModel {}

class ComicsCollection extends IterableBase {
  // ...
  StreamController _onLoad = new StreamController.broadcast(),
                   _onAdd = new StreamController.broadcast();
  List models = [];
  // ...

  // Be List-like
  Iterator get iterator => models.iterator;

  // Be Backbone like
  Stream get onLoad => _onLoad.stream;
  Stream get onAdd => _onAdd.stream;

  add(model) {
    models.add(model);
    _onAdd.add(model);
  }
}

run() {
  group("[collection_event_target]", (){
    test('adding listeners', (){
      var hipster_collection = new ComicsCollection();

      hipster_collection.onAdd
        ..listen((model) { /* listener #1 */ })
        ..listen((model) { /* listener #2 */ })
        ..listen((model) { /* listener #3 */ });

      _test(model) {
        expect(model, isNotNull);
      }

      hipster_collection.onAdd
        ..listen((model) { /* listener #1 */ })
        ..listen(_test);
    });

  });
}
