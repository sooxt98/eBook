library simple_snippet;

import 'dart:html';
import 'dart:async';
import 'package:unittest/unittest.dart';

class DataGenerator {
 static EventStreamProvider<Event> dataEvent =
   new EventStreamProvider('data');
}

run() {
  group("[simple]", (){
    var _el;

    setUp((){
      document.body.append(
        new Element.html('<div id="clicky-box">Click Me</div>')
      );

      var el = document.query('#clicky-box');
      el.onClick.listen((event) {
        el.style.border = "5px solid orange";
      });

      _el = el;
    });

    tearDown((){
      _el.style.border = '';
    });

    test('click event', (){
      var el = _el;
      el.click();
      expect(_el.style.border, contains('orange'));
    });

    test('dispatchEvent event', (){
      var el = _el;
      el.dispatchEvent(new Event('click'));
      expect(_el.style.border, contains('orange'));
    });

    test('remove', (){
      var el = _el;
      var subscription = el.onClick.listen((event) {
        el.style.border = "50px dotted purple";
      });
      // Do some stuff, then...
      subscription.cancel();
      el.click();
      expect(_el.style.border, isNot(contains('purple')));
    });

    test('remove', (){
      var el = _el;
      var errors = [];
      var subscription = el.onClick.listen((event) {
        // Normal click handling here...
      });
      subscription.onError((error) {
        // Add the error to the list of errors...
        errors.add(error);
      });
      el.click();
      expect(errors, []);
    });

    test('iterable', (){
      var el = _el;
      int clicked = 0;
      // Only count clicks where the Control key is also held down:
      el.onClick.
        where((e)=> e.ctrlKey).
        listen((event) {
          clicked++;
        });

      el.click();
      el.click();
      el.click();
      el.dispatchEvent(new MouseEvent('click'));
      el.dispatchEvent(new MouseEvent('click'));
      el.dispatchEvent(new MouseEvent('click'));
      el.dispatchEvent(new MouseEvent('click', ctrlKey: true));
      expect(clicked, 1);

    });

    test('different types on stream', (){
      var stream_controller = new StreamController();
      var seen = [];
      stream_controller.
        stream.
        take(3).
        listen((object) => seen.add(object));

      stream_controller.
        done.
        then(expectAsync((_) {
          expect(seen.length, 3);
        }));

      stream_controller.add('Hi Bob!');
      stream_controller.add(42);
      stream_controller.add(new DateTime.now());
    });

    test('custom event', (){
      var element = _el;
      DataGenerator.
        dataEvent.
        forTarget(element).
        listen(expectAsync((data) {
          print(data);
        }));

      element.dispatchEvent(new Event('data'));
    });
  });
}
