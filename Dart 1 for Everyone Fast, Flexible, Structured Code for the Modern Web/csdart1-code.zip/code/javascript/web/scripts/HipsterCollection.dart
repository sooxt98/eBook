library hipster_collection;

import 'dart:collection';

import 'HipsterModel.dart';

abstract class HipsterCollection extends IterableBase {
  List models = [];

  HipsterModel modelMaker(attrs);
  String get url;

  // Other hip collection stuff goes here...

  // Be List-like
  Iterator get iterator => models.iterator;

  // Be Backbone like
  operator [](id) {
    var ret;
    forEach((model) {
      if (model['id'] == id) ret = model;
    });
    return ret;
  }

  fetch() {
    /*
      would normally do something like:

      var req = new HttpRequest();

      req.onLoad.listen(_handleOnLoad);
      req.open('get', url);
      req.send();
    */
  }

}
