library hipster_model;

class HipsterModel {
  // ...
  var attributes;

  HipsterModel(this.attributes);

  operator [](attr)=> attributes[attr];

  get urlRoot => "";
}
