library hipster_view;

import 'dart:html';

class HipsterView {
  var model, el, collection;

  HipsterView({this.model, this.el, this.collection}) {
    if (this.el is String) this.el = document.query(this.el);
    this.post_initialize();
  }

  void post_initialize() {}
}
