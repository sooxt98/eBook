library comics_collection;

import 'HipsterCollection.dart';
import 'Models.ComicBook.dart';

class Comics extends HipsterCollection {
  // ...

  Comics() {
    this.models = [
      modelMaker({'id': 1, 'title': 'Sandman', 'author': 'Gaiman'})
    ];
  }

  get url => '/comics';
  modelMaker(attrs) => new ComicBook(attrs);
}
