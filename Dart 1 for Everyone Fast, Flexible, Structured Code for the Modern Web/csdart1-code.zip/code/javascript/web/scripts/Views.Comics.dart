library views_comics;

import 'HipsterView.dart';

class Comics extends HipsterView {
  Comics({collection, model, el}):
    super(collection:collection, model:model, el:el) {
    render();
  }

  render() {
    if (el == null) return;
    el.innerHtml = template(collection);
  }

  template(list) {
    // This is silly, but [].forEach is broke
    if (list.length == 0) return '';

    var html = '';
    list.forEach((comic) {
      html += _singleComicBookTemplate(comic);
    });
    return html;
  }

  _singleComicBookTemplate(comic) {
    return """
      <li id="${comic['id']}">
        ${comic['title']}
        (${comic['author']})
      </li>
    """;
  }
}
