library compiling_javascript_tests;

import 'package:unittest/unittest.dart';
import '../main.dart' as Main;
import '../web/scripts/comics.dart' as App;

main () {
  group('[compiling_javascript]', (){
    test('sample file compiles (into Dart)', (){
      expect(Main.main, returnsNormally);
    });

    test('web app returns normally', () {
      expect(App.main, returnsNormally);
    });
  });
}
