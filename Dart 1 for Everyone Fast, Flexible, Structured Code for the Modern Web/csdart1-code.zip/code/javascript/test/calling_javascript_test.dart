library calling_javascript_tests;

import 'package:unittest/unittest.dart';

import 'dart:js';

main () {
  group('[calling_javascript]', (){
    test('calling functions', (){
      var answer = context.callMethod('add', [19, 23]);

      expect(answer , equals(42));
    });

    test('calling object method', (){
      var person = new JsObject(context['Person'], ['Bob']);

      var greeting =
        person.callMethod('greet', []);
        // => 'Howdy, Bob!'

      expect(greeting, equals('Howdy, Bob!'));
    });

    test('setting property', (){
      var person = new JsObject(context['Person'], ['Bob']);
      person['name'] = 'Fred';

      var greeting =
        person.callMethod('greet', []);
        // => 'Howdy, Fred!'

      expect(greeting, equals('Howdy, Fred!'));
    });

    test('passing callbacks', (){
      var answer = context.callMethod('multiply', [2, ()=> 84/4]);

      expect(answer, equals(42));
    });
  });
}
