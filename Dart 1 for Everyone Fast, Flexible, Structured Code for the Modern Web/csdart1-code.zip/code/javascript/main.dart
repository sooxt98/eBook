main() {
  var foo;
  var bar;
  // Uncomment to get error in the text...
  //document.query('#foo');
}
