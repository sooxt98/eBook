library first_order_snippet;

import 'package:unittest/unittest.dart';
import 'dart:mirrors';

add(x, y, z) {
  return x + y + z;
}
makeAdder2(fn, arg1) {
  return (y, z) {
    return fn(arg1, y, z);
  };
}
var add10 = makeAdder2(add, 10);

make2(fn, arg1) {
  return (x, y) {
    return Function.apply(fn, [x, y, arg1]);
  };
}

curriedAddManual(arg1) =>
  (arg2) =>
  (arg3) =>
  add(arg1, arg2, arg3);

    // if (args.positionalArguments.length == 1)
    //   return (x) {
    //     return (y) {
    //       var _args = [x, y]..addAll(args.positionalArguments);
    //       return Function.apply(add, _args);
    //     };
    //   };

@proxy
class Foo {
  noSuchMethod(args) {
    if (args.positionalArguments.length == 1)
      return (x) {
        return (y) {
          var _args = [x, y]..addAll(args.positionalArguments);
          return Function.apply(add, _args);
        };
      };
  }
}

class Curry {
  static final Curry currier = new Curry._internal();
  static get make => currier;
  factory Curry() {
    return currier;
  }
  Curry._internal();

  noSuchMethod(args) {
    if (args.memberName == #send || args.memberName == #call) {
      return _curry(args.positionalArguments);
    }

    return super.noSuchMethod(args);
  }

  _curry(args) {
    var fn = args[0];
    var bound = args.sublist(1);
    ClosureMirror cm = reflect(fn);
    var size = cm.function.parameters.length;

    var im = reflect(this);
    return (_) {
      var _args = [_]..addAll(bound);

      if (_args.length < size)
        return im.invoke(#send, [fn]..addAll(_args)).reflectee;

      return Function.apply(fn, _args);
    };
  }
}

run() {
  group("[first_order]", (){
    test('partial application', (){
      var _add =
      add10(1,1); // => 12

      expect(_add, equals(12));
    });

    test('Manual curry', (){
      expect(curriedAddManual(1)(1)(1), 3);
    });

    test('Function.apply', (){
      var add100 = make2(add, 100);
      expect(add100(1, 1), 102);
    });

    test('Curry.send()', (){
      var curried = Curry.make.send(add, 1, 2);
      expect(curried(3), 6);
    });

    test('Curry call()', (){
      var curried = Curry.make(add, 1, 2);
      expect(curried(3), 6);
    });

    test('Curry.make one argument', (){
      var curried_1 = Curry.make(add, 1);
      expect(curried_1(2)(3), 6);
    });

    test("Curry3", (){
      expect(
        new Foo().bar(1)(2)(3),
        6
      );
    });

    test("Curry1", (){
      var curry = new Foo().bar(1);
      expect(curry(2)(3), 6);
    });
  });
}
