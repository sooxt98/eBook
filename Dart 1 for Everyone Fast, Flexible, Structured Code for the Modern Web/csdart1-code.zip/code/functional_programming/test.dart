library functional_tests;

import 'fib.dart' as Fib;
import 'first_order.dart' as FirstOrder;
import 'optional.dart' as Optional;

main () {
  Fib.run();
  FirstOrder.run();
  Optional.run();
}
