library optional_snippet;

import 'package:unittest/unittest.dart';

var _prints = [];
print(val) => _prints.add(val);

good_day(name, {emphatic}) {
  print("Good day, ${name}.");
  if (emphatic) {
    print("I said good day!");
  }
}

profile(name, {hero:"Weird Al", favorite_color}) {
  print("Name: ${name}");
  print("  personal hero: ${hero}");
  if (favorite_color != null) {
    print("  favorite color: ${favorite_color}");
  }
}

movie(title, [starring="Leslie Nielson", co_starring]) {
  print("Great movie: ${title}");
  print("  Starring: ${starring}");
  if (co_starring != null) {
    print("  Co-starring: ${co_starring}");
  }
}

run() {
  group("[optional parameters]", (){
    setUp(() => _prints = []);

    test('required only', (){
      good_day("Bob");
      // Good day, Bob.
      expect(
        _prints,
        equals(['Good day, Bob.'])
      );
    });

    test('optional named parameter', (){
      good_day("Bob", emphatic: true);
      // Good day, Bob.
      // I said good day!

      expect(_prints, equals([
        'Good day, Bob.',
        'I said good day!'
      ]));
    });

    test('default optional parameter', (){
      profile("Bob");
      // Name: Bob
      //   personal hero: Weird Al

      expect(_prints, equals([
        'Name: Bob',
        '  personal hero: Weird Al'
      ]));
    });

    test('specifying a default, optional parameter', (){
      profile("Bob", favorite_color: 'Purple', hero: 'Frank Drebin');
      // Name: Bob
      //   personal hero: Frank Drebin
      //   favorite color: Purple

      expect(_prints, equals([
        'Name: Bob',
        '  personal hero: Frank Drebin',
        '  favorite color: Purple'
      ]));
    });


    test('optional positional parameters', (){
      movie("The Naked Gun");
      // Great movie: The Naked Gun
      //   Starring: Leslie Nielson

      expect(_prints, equals([
        'Great movie: The Naked Gun',
        '  Starring: Leslie Nielson'
      ]));
    });

    test('specifying optional, positional parameters', (){
      movie("Airplane!", "Robert Hays", "Leslie Nielson");
      // Great movie: The Naked Gun
      //   Starring: Robert Hays
      //   Co-starring: Leslie Nielson

      expect(_prints, equals([
        'Great movie: Airplane!',
        '  Starring: Robert Hays',
        '  Co-starring: Leslie Nielson'
      ]));
    });
  });
}
