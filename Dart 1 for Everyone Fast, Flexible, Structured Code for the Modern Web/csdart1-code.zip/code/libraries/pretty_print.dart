var INDENT = '  ';
pretty_print(thing) {
  if (thing is List) print("$INDENT ${Strings.join(thing, ', ')}");
  else print(thing);
}
