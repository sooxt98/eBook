library comics_view;

class Comics {
  var el, collection;
  Comics({this.el, this.collection});
}
