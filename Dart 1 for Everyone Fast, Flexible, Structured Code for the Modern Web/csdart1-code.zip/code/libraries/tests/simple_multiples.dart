library simple_multiples_test;

import 'package:unittest/unittest.dart';

import '../simple_multiples.dart';

run() {
  group("[regular functions]", (){
    test('just work™', (){
      expect(quadruple_triple_double(3), equals(72));
    });
  });
}
