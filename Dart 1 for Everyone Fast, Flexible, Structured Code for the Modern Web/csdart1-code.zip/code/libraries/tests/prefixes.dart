library prefixes_test;

import 'package:unittest/unittest.dart';

import '../prefixed_imports.dart' as Prefixes;

run() {
  group("[prefixes]", (){
    test('can use classes of the same name with prefixes', (){
      expect(Prefixes.main, returnsNormally);
    });
  });
}
