library part_access_test;

import 'package:unittest/unittest.dart';

import '../sum_of_parts.dart' as Parts;

run() {
  group("[main]", (){
    test('can call functions defined directly in library', (){
      expect(Parts.double(3), equals(6));
    });

    test('functions in parts can call functions defined in main library', (){
      expect(Parts.triple_double(3), equals(18));
    });

    test('functions in parts can call functions in other parts', (){
      expect(Parts.quadruple_triple_double(3), equals(72));
    });

    test('parts have access to variables', (){
      expect(Parts.one_plus_two_plus_three_plus(4), equals(10));
    });
  });
}
