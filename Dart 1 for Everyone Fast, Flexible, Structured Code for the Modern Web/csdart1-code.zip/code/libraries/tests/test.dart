library library_tests;

import 'simple_multiples.dart' as SimpleMultiples;
import 'part_access.dart' as PartAccess;
import 'library.dart' as Library;
import 'prefixes.dart' as Prefixes;

main () {
  SimpleMultiples.run();
  PartAccess.run();
  Library.run();
  Prefixes.run();
}
