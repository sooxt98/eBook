library library_test;

import 'package:unittest/unittest.dart';

import '../time_counting.dart' as Timer;

run() {
  group("[library]", (){
    test('can create objects from a library', (){
      expect(Timer.main, returnsNormally);
    });
  });
}
