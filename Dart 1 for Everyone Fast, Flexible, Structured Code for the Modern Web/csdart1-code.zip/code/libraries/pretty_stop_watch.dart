library pretty_stop_watch;

class PrettyStopwatch {
  Stopwatch timer = new Stopwatch();

  PrettyStopwatch.running() {
    timer = new Stopwatch()..start();
  }
  start() {
    timer.start();
  }
  stop() {
    timer.stop();
    print("Elapsed time: ${timer.elapsedMilliseconds} ms");
  }
}
