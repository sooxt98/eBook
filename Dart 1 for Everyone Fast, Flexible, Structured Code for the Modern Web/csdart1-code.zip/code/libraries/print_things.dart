#source('pretty_print.dart');

main() {
  var array = ['1','2','3']
    , hash = {'1':'foo','2':'bar','3':'baz'}
    , string = "Dart is awesome";

  pretty_print(array);
  pretty_print(hash);
  pretty_print(string);
}
