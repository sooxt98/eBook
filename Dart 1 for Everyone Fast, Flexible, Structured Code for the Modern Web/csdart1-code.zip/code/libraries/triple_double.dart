part of simple_multiples;
triple_double(x) => 3 * double(x);

var two = 2;

one_plus_two_plus_three_plus(x) => one + two + three + x;
