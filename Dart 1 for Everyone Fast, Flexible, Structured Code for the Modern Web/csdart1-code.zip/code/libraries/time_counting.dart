library time_counting;

import 'pretty_stop_watch.dart';

main() {
  var timer = new PrettyStopwatch.running();
  for(var i=0; i<10000000; i++) {
    // just counting
  }
  timer.stop();
}
