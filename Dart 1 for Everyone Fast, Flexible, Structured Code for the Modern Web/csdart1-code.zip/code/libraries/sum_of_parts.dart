library simple_multiples;
part 'quadruple_triple_double.dart';
part 'triple_double.dart';
double(x) => 2 * x;

var one = 1;
