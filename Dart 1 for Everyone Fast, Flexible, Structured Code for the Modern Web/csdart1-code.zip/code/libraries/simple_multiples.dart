library simple_multiples;
quadruple_triple_double(x) => 4 * triple_double(x);
triple_double(x) => 3 * double(x);
double(x) => 2 * x;
