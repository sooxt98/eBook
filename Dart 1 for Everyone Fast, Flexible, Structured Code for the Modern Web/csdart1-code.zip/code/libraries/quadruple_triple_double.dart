part of simple_multiples;
quadruple_triple_double(x) => 4 * triple_double(x);

var three = 3;
