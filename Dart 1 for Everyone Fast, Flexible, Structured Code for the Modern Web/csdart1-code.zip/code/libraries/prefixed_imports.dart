library prefixed_imports;

import 'collections/Comics.dart' as Collections;
import 'views/Comics.dart' as Views;
import 'views/AddComic.dart' as Views;

class Document {
  query(str) => false;
}
var document = new Document();

main() {
  var my_comics_collection = new Collections.Comics(),
      comics_view = new Views.Comics(
        el:document.query('#comics-list'),
        collection: my_comics_collection
      );
}
