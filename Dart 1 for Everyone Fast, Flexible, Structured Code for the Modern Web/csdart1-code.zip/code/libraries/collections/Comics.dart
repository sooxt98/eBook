library comics;

class Comics {}
