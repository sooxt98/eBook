#import("dart:html");

int width = 900, height = 450;

main() {
  final me = new Player(
    x: (width/2).toInt(),
    y: (height/2).toInt()
  );

  CanvasElement canvas = buildCanvas(width, height);
  CanvasRenderingContext context = canvas.getContext("2d");

  draw(me, context);
  attachMover(me, context);
}

CanvasElement buildCanvas(width, height) {
  var canvas = new Element.html('<canvas/>');
  canvas.width = width;
  canvas.height = height;

  document.
    body.
    nodes.
    add(canvas);

  return canvas;
}

draw(me, context) {
  int width = context.canvas.width,
      height = context.canvas.height;

  // start drawing
  context.beginPath();

  // clear drawing area
  context.clearRect(0,0,width,height);
  context.fillStyle = 'white';
  context.fillRect(0,0,width,height);

  // draw me
  context.rect(me.x, me.y, 20, 20);

  context.fillStyle = 'red';
  context.fill();

  context.strokeStyle = 'black';
  context.stroke();

  // done drawing
  context.closePath();
}

attachMover(me, context) {
  // Move on key down
  document.
    on.
    keyDown.
    add((event) {
      String direction;

      if (event.keyCode == 37) direction = 'left';
      if (event.keyCode == 38) direction = 'up';
      if (event.keyCode == 39) direction = 'right';
      if (event.keyCode == 40) direction = 'down';

      if (direction != null) {
        event.preventDefault();
        me.move(direction);
        draw(me, context);
      }
    });

  // // Stop on key up
  // document.
  //   on.
  //   keyUp.
  //   add((event) {
  //     direction = null;
  //   });
}

animate() {
  window.
    setInterval(() {
      print("internval direction: $direction");
      if (direction != null) {
        me.move(direction);
        print("x: ${me.x}, y: ${me.y}");
        draw();
      }
    }, 500);
}

class Player {
  int x, y;

  Player(): this.xy(0,0);

  Player.xy([this.x, this.y]) {
    if (x == null) x = 0;
    if (y == null) y = 0;
  }

  move(String dir) {
    if (dir == 'left') x-= 10;
    if (dir == 'right') x+= 10;
    if (dir == 'up') y-= 10;
    if (dir == 'down') y+= 10;
  }
}
