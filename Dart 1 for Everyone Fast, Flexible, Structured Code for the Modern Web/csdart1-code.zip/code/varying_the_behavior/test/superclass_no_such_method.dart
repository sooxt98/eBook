library superclass_no_such_method_snippet;

import 'package:unittest/unittest.dart';

@proxy
class A {
  noSuchMethod(args) {
    if (args.isMethod && args.memberName == const Symbol("bar")) {
      return 2 * args.
        positionalArguments.
        fold(0, (prev, element) => prev + element);
    }

    return super.noSuchMethod(args);
  }
}

class B extends A {}

class C extends A {
  noSuchMethod(args) {
    return super.noSuchMethod(args);
  }
}

run() {
  group("[noSuchMethod]", (){
    test('can access noSuchMethod in superclass when not defined in subclass', (){
      var b = new B();
      expect(()=> b.bar(), returnsNormally);
    });

    test('sees noSuchMethod when not defined in superclass or subclass', (){
      var c = new C();
      expect(()=> c.foo(), throwsNoSuchMethodError);
    });

    test('can access noSuchMethod in superclass when defined in subclass', (){
      var c = new C();
      expect(()=> c.bar(2, 2), returnsNormally);
    });

    test('can pass parameters to noSuchMethod in superclass', (){
      var c = new C();
      expect(c.bar(2,2), equals(2*(2+2)));
    });

  });
}
