library local_store_subclass_test;

import 'package:unittest/unittest.dart';
import '../public/scripts/Models.LocalComic.dart';

run() {
  group("[old HipsterModel]", (){

    test('can create', (){
      var model = new LocalComic({'title': 'Sandman'});
      expect(model.attributes['title'], 'Sandman');
    });

  });
}
