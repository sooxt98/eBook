library calling_methods_from_no_such_method_snippet;

import 'package:unittest/unittest.dart';
import 'dart:mirrors';

@proxy
class HipsterModel {
  bool useLocal;
  // ...
  noSuchMethod(args) {
    // Guard clauses here ...
    if (args.memberName != #save) {
      throw "Yikes ${MirrorSystem.getName(args.memberName)}";
    }
    if (useLocal) {
      // THIS WON'T WORK
      _localSave(args);
    }
    else {
      // THIS WON'T WORK
      _ajaxSave(args);
    }
  }
  _localSave({callback}) { /* ... */ }
  _ajaxSave({callback}) { /* ... */ }
}

run() {
  group("[bad invocation from noSuchMethod]", (){
    test('cannot supply invocation mirror arguments', (){
      var m = new HipsterModel();
      expect(()=> m.save(), throwsA("Yikes _ajaxSave"));
      // expect(()=> m.save(), returnsNormally);
    });
  });
}
