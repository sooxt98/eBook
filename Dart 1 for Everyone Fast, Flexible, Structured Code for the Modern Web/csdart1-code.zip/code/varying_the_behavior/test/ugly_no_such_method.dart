library ugly_methods_from_no_such_method_snippet;

import 'package:unittest/unittest.dart';

@proxy
class HipsterModel {
  bool useLocal;
  final CB = const Symbol('callback');
  // ...
  noSuchMethod(args) {
    // Guard clauses here...
    if (useLocal) {
      _localSave(callback: args.namedArguments[CB]);
    }

    else {
      _ajaxSave(callback: args.namedArguments[CB]);
    }
  }
  _localSave({callback}) { /* ... */ }
  _ajaxSave({callback}) {
    // Save over HTTP, then invoke callback...
    if (callback != null) callback(new Event('Save'));
  }
}

class Event {
  var name;
  Event(this.name);
}

run() {
  group("[invocation from noSuchMethod]", (){
    test('manually supply invocation mirror arguments', (){
      var m = new HipsterModel();
      m.save(callback: expectAsync((event) {
        expect(event.name, equals('Save'));
      }));
    });
  });
}
