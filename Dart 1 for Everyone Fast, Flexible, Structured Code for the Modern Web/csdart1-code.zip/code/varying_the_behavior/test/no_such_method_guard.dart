library no_such_method_guard_snippet;

import 'package:unittest/unittest.dart';

@proxy
class HipsterModel {
  // ...
  noSuchMethod(args) {
    if (args.memberName != #save) {
      return super.noSuchMethod(args);
    }
    // ...
  }
}

run() {
  group("[noSuchMethod guard clause]", (){
    test('returns null when guard clause is bypassed', (){
      var m = new HipsterModel();
      expect(m.save(), isNull);
    });

    test('throws an error when guard clause is matched', (){
      var m = new HipsterModel();
      expect(()=> m.foo(), throwsNoSuchMethodError);
    });
  });
}
