library invoke_ok_snippet;

import 'package:unittest/unittest.dart';

class HipsterModel {
  bool useLocal;
  // ...
  noSuchMethod(args) {
    // guard clauses ...
    if (args.memberName != 'save') {
      throw new NoSuchMethodError(
        this,
        args.memberName,
        args.positionalArguments,
        args.namedArguments
      );
    }
    if (useLocal) {
      // THIS WON'T WORK
      _localSave(args);
    }

    else {
      // THIS WON'T WORK
      var ret = _ajaxSave(args);
    }
  }
  _localSave({callback}) { /* ... */ }
  _ajaxSave({callback}) { /* ... */ }
}

run() {
  group("[bad invocation from noSuchMethod]", (){
    test('cannot supply invocation mirror arguments', (){
      var m = new HipsterModel();
      expect(()=> m.save(), throwsNoSuchMethodError);
    });
  });
}
