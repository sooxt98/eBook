library old_hipster_model_test;

import 'package:unittest/unittest.dart';
import '../../mvc_library/public/scripts/HipsterModel.dart';

run() {
  group("[old HipsterModel]", (){

    test('can save', (){
      var model = HipsterModel();
      expect(c.bar(2,2), equals(2*(2+2)));
    });

  });
}
