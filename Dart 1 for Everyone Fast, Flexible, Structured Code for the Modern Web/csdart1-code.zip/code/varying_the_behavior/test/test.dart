library varying_behavior_tests;

import 'superclass_no_such_method.dart' as SuperNoSuchMethod;
import 'local_store_subclass.dart' as LocalStoreSubclass;
import 'no_such_method_guard.dart' as NoSuchMethodGuard;
import 'calling_methods_from_no_such_method.dart' as FromNoSuchMethod;
import 'ugly_no_such_method.dart' as UglyNoSuchMethod;

main () {
  SuperNoSuchMethod.run();
  LocalStoreSubclass.run();
  NoSuchMethodGuard.run();
  FromNoSuchMethod.run();
  UglyNoSuchMethod.run();
}
