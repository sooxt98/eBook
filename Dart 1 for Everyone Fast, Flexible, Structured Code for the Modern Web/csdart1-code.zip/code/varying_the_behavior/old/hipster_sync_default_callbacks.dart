class HipsterSync {
  static _default_sync(method, model, [options]) {
    var req = new HttpRequest();
    _attachCallbacks(req, options);
    // ...
  }
  static _attachCallbacks(request, options) {
    if (options == null) return;
    if (options.containsKey('onLoad')) {
      request.onLoad.listen((event) {
        var req = event.target,
            json = JSON.parse(req.responseText);
        options['onLoad'](json);
      });
    }
  }
}
