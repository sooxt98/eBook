#library('Sync layer for HipsterMVC');
#import('dart:json');

class HipsterSync {
  static _defaultSync(method, model, [options]) {
    var req = new HttpRequest();
    _attachCallbacks(req, options);
    req.open(method, model.url, true);
    // POST and PUT HTTP request bodies if necessary
    if (method == 'post' || method == 'put') {
      req.setRequestHeader('Content-type', 'application/json');
      req.send(JSON.stringify(model.attributes));
    }
    else {
      req.send();
    }
  }
}
