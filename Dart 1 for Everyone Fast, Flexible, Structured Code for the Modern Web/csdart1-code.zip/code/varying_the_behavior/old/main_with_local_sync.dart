import 'HipsterSync.dart';
main() {
  HipsterSync.sync = localSync;
  // Setup collections and views ...
}
localSync(method, model, [options]) {
  if (method == 'get') {
    var json =  window.localStorage[model.url],
        data = (json == null) ? {} : JSON.decode(json);
    if (options is Map && options.containsKey('onLoad')) {
      options['onLoad'](data.getValues());
    }
  }
}
