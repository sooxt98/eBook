class HipsterModel {
  // ...
  save([callback]) {
    var req = new HttpRequest()
      , json = JSON.stringify(attributes);

    req.onLoad.listen((event) {
      attributes = JSON.parse(req.responseText);
      on.save.dispatch(event);
      if (callback != null) callback(event);
    });

    req.open('post', '/comics', true);
    req.setRequestHeader('Content-type', 'application/json');
    req.send(json);
  }
}
