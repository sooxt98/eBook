class HipsterModel {
  // ...
  save([callback]) {
    HipsterSync.send('post', this, options: {
      'onLoad': (attrs) {
        attributes = attrs;
        var event = new ModelEvent('save', this);
        onLoad.dispatch(event);
        if (callback != null) callback(event);
      }
    });
  }
  // ...
}
