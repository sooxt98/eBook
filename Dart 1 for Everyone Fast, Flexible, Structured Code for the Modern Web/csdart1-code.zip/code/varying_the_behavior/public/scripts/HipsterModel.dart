library hipster_model;
import 'HipsterSync.dart';
import 'HipsterCollection.dart';

class HipsterModel {
  Map attributes;
  HipsterCollection collection;

  HipsterModel(this.attributes);

  static String hash() {
    return (new DateTime.now()).hashCode.toRadixString(16);
  }

  operator [](attr) => attributes[attr];

  get url => isSaved() ?
      urlRoot : "$urlRoot/${attributes['id']}";

  get urlRoot => (collection == null) ?
    "" : collection.url;

  isSaved() => attributes['id'] == null;

  delete({callback}) {
    HipsterSync.send('delete', this, options: {
      'onLoad': (attrs) {
        var event = new ModelEvent('delete', this);
        if (callback != null) callback(event);
      }
    });
  }

  // ...
  save({callback}) {
    HipsterSync.send('post', this, options: {
      'onLoad': (attrs) {
        attributes = attrs;
        if (callback != null) callback(this);
      }
    });
  }
}

class ModelEvent {
  String type;
  HipsterModel model;
  ModelEvent(this.type, this.model);
}
