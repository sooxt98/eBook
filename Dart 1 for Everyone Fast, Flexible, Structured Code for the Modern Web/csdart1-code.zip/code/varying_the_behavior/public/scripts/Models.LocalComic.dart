library local_comic_book;

import 'dart:convert';
import 'dart:html';

import 'HipsterModel.dart';

class LocalComic extends HipsterModel {
  LocalComic(attributes) : super(attributes);

  save({callback}) {
    var id = (attributes['id'] != null) ?
      attributes['id'] : hashCode.toString();

    var json = window.localStorage[urlRoot],
        data = (json != null) ? JSON.decode(json) : {};

    attributes['id'] = id;
    data[id] = attributes;

    window.localStorage[urlRoot] = JSON.encode(data);

    if (callback != null) callback(data);
  }

  get urlRoot => "/comics";

  //...
}
