library hipster_model;

import 'dart:html';
import 'dart:async';
import 'dart:convert';

class HipsterModel {
  // ...
  var attributes;
  StreamController<HipsterModel> _onSave, _onDelete;
  Stream get onSave => _onSave.stream;
  Stream get onDelete => _onDelete.stream;

  HipsterModel(this.attributes);

  operator [](attr)=> attributes[attr];

  get urlRoot => "";

  delete({callback}) {
    var req = new HttpRequest();

    req.onLoad.listen((event) {
      print("[delete] success");
      _onDelete.add(this);
      if (callback != null) callback(event);
    });

    req.open('delete', "${urlRoot}/${attributes['id']}");
    req.send();
  }

  save({callback}) {
    var req = new HttpRequest();
    req.onLoad.listen((event) {
      attributes = JSON.decode(req.responseText);
      _onSave.add(this);
      if (callback != null) callback(this);
    });

    req.open('post', urlRoot);
    req.setRequestHeader('Content-type', 'application/json');
    req.send(json);
  }
  String get json => JSON.encode(attributes);
}
