library mvc_library_tests;

import 'collection_skel.dart' as CollectionSkel;
import 'superclass_access_to_subclass_ivar.dart' as SuperclassAccess;
import 'model_maker_method.dart' as ModelMaker;
import 'model.dart' as Model;
import 'view.dart' as View;
import 'library_test.dart' as Library;

main () {
  CollectionSkel.run();
  SuperclassAccess.run();
  ModelMaker.run();
  Model.run();
  View.run();
  Library.run();
}
