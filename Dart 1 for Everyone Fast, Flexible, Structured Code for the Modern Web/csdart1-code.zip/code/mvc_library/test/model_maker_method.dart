library model_make_method_snippet;

import 'package:unittest/unittest.dart';
import 'dart:collection';

class Collection {}

class HipsterModel {}
class ComicBook extends HipsterModel {
  var attributes;
  ComicBook(this.attributes);

  save({callback}) {
    if (callback != null) callback(null);
  }
}

class ComicsCollection extends HipsterCollection {
  var url = '/comics';
  modelMaker(attrs) => new ComicBook(attrs);
}

abstract class HipsterCollection extends IterableBase {
  HipsterModel modelMaker(Map attrs);
  // ...
  create(attrs) {
    var new_model = modelMaker(attrs);
    new_model.save(callback:(event) {
      this.add(new_model);
    });
  }

  var models = [];
  Iterator get iterator => models.iterator;
  add(model) => models.add(model);

  // ...
}


run() {
  group("[model maker method]", (){
    test('can create new models in the collection', (){
      var collection = new ComicsCollection();
      collection.create({'title': 'Sandman'});
      // collection.length increases by 1
      expect(
        collection.length,
        equals(1)
      );
    });
  });
}
