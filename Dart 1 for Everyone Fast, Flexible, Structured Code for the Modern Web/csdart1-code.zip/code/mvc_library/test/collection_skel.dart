library collection_skel_snippet;

import 'package:unittest/unittest.dart';
import 'dart:async';
import 'dart:collection';

class HipsterCollection extends IterableBase {
  // Lazily evaluated instance variables
  StreamController _onLoad, _onAdd;
  var models = [];

  // MVC
  fetch() { /* ... */ }
  create(attrs) { /* ... */ }
  add(model) { /* ... */ }

  // Iterable
  Iterator get iterator => models.iterator;

}

run() {
  group("[skeleton]", (){
    test('can instantiate', (){
      expect(
        ()=> new HipsterCollection(),
        returnsNormally
      );
    });
  });
}
