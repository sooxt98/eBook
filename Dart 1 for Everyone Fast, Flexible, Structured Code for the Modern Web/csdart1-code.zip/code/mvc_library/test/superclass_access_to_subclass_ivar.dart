library superclass_ivar_access_snippet;

import 'package:unittest/unittest.dart';

class IterableBase {}

abstract class HipsterCollection extends IterableBase {
  void set url(v);
  String get url;

  fetch() {
    // HTTP Request url from subclass
  }
  get starredUrl => "*** ${url} ***";
  // ...
}

class ComicsCollection extends HipsterCollection {
  var url = '/comics';
}

run() {
  group("[superclass access]", (){
    test('cannot access subclass ivar', (){
      var comics_collection = new ComicsCollection();
      expect(
        comics_collection.starredUrl,
        equals('*** /comics ***')
      );
    });
  });
}
