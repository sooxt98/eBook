library library_tests;

import 'dart:html';

import 'package:unittest/unittest.dart';

import '../public/scripts/Collections.Comics.dart' as Collections;
import '../public/scripts/Views.Comics.dart' as Views;

run() {
  group("[library]", (){
    test('can create collection', (){
      var my_comics_collection = new Collections.Comics();
      expect(
        my_comics_collection.length,
        equals(0)
      );
    });

    test('can create collection view', (){
      var my_comics_collection = new Collections.Comics(),
          comics_view = new Views.Comics(
            el: new DivElement(),
            collection: my_comics_collection
          );

      expect(
        comics_view.collection,
        equals(my_comics_collection)
      );
    });

  });
}
