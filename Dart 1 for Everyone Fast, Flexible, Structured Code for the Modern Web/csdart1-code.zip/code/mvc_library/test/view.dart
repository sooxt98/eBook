library view_snippet;

import 'package:unittest/unittest.dart';

class HipsterView {
  var el, model, collection;
  HipsterView({this.el, this.model, this.collection});
}

class ComicBookView extends HipsterView {
  ComicBookView({el, model, collection}):
    super(el:el, model:model, collection:collection);
}

class ComicsListing extends HipsterView {
  ComicsListing({el, model, collection}):
    super(el:el, model:model, collection:collection) {
    _attachUiHandlers();
    _subscribeEvents();
  }

  int privatesCalled = 0;
  _attachUiHandlers() {
    privatesCalled++;
  }

  _subscribeEvents() {
    privatesCalled++;

  }
}

run() {
  group("[view]", (){
    test('can create a new view', (){
      var view = new ComicBookView(el:"Element");
      expect(
        view.el,
        equals('Element')
      );
    });

    test('redirecting constructor can call privates', (){
      var view = new ComicsListing(el:"Element");
      expect(
        view.privatesCalled,
        equals(2)
      );
    });
  });
}
