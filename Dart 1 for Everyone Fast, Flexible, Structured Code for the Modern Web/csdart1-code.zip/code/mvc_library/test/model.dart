library model_snippet;

import 'package:unittest/unittest.dart';

class HipsterModel {
  var attributes;
  HipsterModel(this.attributes);
}

class ComicBook extends HipsterModel {
  ComicBook(attributes) : super(attributes);
  get urlRoot => '/comics';
}


run() {
  group("[model]", (){
    test('can create a new model', (){
      var model = new ComicBook({'title': 'Sandman'});
      expect(
        model.attributes['title'],
        equals('Sandman')
      );
    });
  });
}
