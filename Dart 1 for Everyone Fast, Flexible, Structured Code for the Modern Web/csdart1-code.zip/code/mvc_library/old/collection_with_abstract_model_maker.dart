class HipsterCollection implements Collection {
  abstract HipsterModel modelMaker(attrs);
  // ...
  create(attrs) {
    var new_model = modelMaker(attrs);
    new_model.save(callback:(event) {
      this.add(new_model);
    });
  }
}
