class HipsterModel {
  // ...
  get url() => isSaved() ?
    urlRoot : "$urlRoot/${attributes['id']}";

  get urlRoot() => collection ?
    collection.url : "";

  isSaved() => attributes['id'] == null;
}
