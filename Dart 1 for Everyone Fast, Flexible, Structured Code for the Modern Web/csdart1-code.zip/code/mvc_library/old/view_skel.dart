class HipsterView {
  HipsterCollection collection;
  HipsterModel model;
  Element el;

  HipsterView([el, this.model, this.collection]) {
    this.post_initialize();
  }

  void post_initialize() { }

  // delegate events
  attachHandler(parent, event_selector, callback) {
    // ...
  }
}
