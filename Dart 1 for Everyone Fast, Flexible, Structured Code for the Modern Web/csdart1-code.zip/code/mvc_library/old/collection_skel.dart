class HipsterCollection implements Collection {
  // Lazily evaluated instance variables
  var on = new CollectionEvents();
  var models = [];

  // MVC
  fetch() { /* ... */ }
  create(attrs) { /* ... */ }
  add(model) { /* ... */ }

  // Collection
  void forEach(fn) { /* ... */ }
  int get length() { /* ... */ }
  operator [](id) { /* ... */ }
}
class CollectionEvent implements Event { /* ... */ }
class CollectionEvents implements Events { /* ... */ }
class CollectionEventList implements EventListenerList { /* ... */ }
