class HipsterCollection implements Collection {
  abstract String get url();
  // ...
}
