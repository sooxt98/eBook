#library('Base class for Models');

#import('HipsterCollection.dart');

class HipsterModel {
  Map attributes;
  ModelEvents on;
  HipsterCollection collection;

  HipsterModel(this.attributes) {
    on = new ModelEvents();
  }
}
