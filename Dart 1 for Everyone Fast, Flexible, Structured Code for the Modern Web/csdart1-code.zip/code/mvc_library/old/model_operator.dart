class HipsterModel {
  // ...
  operator [](attr) => attributes[attr];
}
