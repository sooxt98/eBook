class Comics extends HipsterView {
  // ...
  render() {
    el.innerHTML = template(collection);
  }

  template(list) {
    if (list.length == 0) return '';

    var html = '';
    list.forEach((comic) {
      html = html.concat(
        _singleComicBookTemplate(comic)
      );
    });
    return html;
  }

  _singleComicBookTemplate(comic) {
    return """
      <li id="${comic['id']}">
        ${comic['title']}
        (${comic['author']})
        <a href="#" class="delete">[delete]</a>
      </li>""";
  }
}
