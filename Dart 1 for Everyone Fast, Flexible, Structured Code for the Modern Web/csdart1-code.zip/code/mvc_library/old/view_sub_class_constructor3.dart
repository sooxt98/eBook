class Comics extends HipsterView {
  Comics([collection, el]):
    super(collection:collection, el:el);

  post_initialize() {
    _subscribeEvents();
    _attachUiHandlers();
  }
}
