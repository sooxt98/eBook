#library('Base class for Views');

#import('dart:html');

#import('HipsterCollection.dart');
#import('HipsterModel.dart');

class HipsterView {
  HipsterCollection collection;
  HipsterModel model;
  Element el;
}
