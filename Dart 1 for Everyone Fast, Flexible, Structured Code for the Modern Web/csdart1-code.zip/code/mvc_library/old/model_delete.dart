class HipsterModel {
  // ...
  delete([callback]) {
    var req = new HttpRequest();

    req.onLoad.listen((event) {
      var request = load_event.target;

      var event = new ModelEvent('delete', this);
      on.delete.dispatch(event);
      if (callback != null) callback(event);
    });

    req.open('delete', "${url}", true);
    req.send();
  }
}
