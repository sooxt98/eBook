class HipsterView {
  // ...
  HipsterView([el, this.model, this.collection]) {
    this.el = (this.el is Element) ? el : document.query(el);
    this.post_initialize();
  }

  void post_initialize() { }
}
