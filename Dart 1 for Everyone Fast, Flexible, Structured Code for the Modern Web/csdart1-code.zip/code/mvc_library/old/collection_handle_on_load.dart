class HipsterCollection implements Collection {
  //  ...
  _handleOnLoad(list) {
    list.forEach((attrs) {
      var new_model = modelMaker(attrs);
      new_model.collection = this;
      models.add(new_model);
    });

    onLoad.dispatch(new CollectionEvent('load', this));
  }
}
