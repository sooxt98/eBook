class ComicBook extends HipsterModel {
  ComicBook(attributes) : super(attributes);
}
