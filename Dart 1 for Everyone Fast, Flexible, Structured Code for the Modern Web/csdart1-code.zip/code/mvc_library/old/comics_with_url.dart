class ComicsCollection extends HipsterCollection {
  get url() => '/comics';
}
