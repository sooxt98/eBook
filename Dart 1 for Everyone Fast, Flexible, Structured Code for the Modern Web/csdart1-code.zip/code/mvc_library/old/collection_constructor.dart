class HipsterCollection implements Collection {
  CollectionEvents on;
  List models;

  HipsterCollection() {
    on = new CollectionEvents();
    models = [];
  }
}
