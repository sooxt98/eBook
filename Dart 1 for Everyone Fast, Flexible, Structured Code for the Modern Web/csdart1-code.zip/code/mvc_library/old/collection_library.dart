#library('hipster_collection');

#import('dart:html'); // For events
#import('dart:json');

class HipsterCollection implements Collection {
  // Hip Collection stuff goes here...
}
