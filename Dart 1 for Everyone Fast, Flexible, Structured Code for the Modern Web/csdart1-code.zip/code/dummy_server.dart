import 'package:plummbur_kruk/server.dart' as Server;

main()=> Server.main();
