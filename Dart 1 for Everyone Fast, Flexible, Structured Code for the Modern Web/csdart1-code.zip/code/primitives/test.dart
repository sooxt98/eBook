library primitives_test;

import 'numbers.dart' as Numbers;
import 'strings.dart' as Strings;
import 'string_concat.dart' as StringConcat;
import 'strings_triple.dart' as StringsTriple;
import 'strings_adjacent.dart' as StringsAdjacent;
import 'strings_interpolation.dart' as StringsInterpolation;
import 'booleans.dart' as Booleans;
import 'hash_map.dart' as HashMaps;
import 'hash_put_if_absent.dart' as HashPutIfAbsent;
import 'lists.dart' as Lists;
import 'list_iterators.dart' as ListIterators;
import 'set.dart' as Set;
import 'queue.dart' as Queue;
import 'dates.dart' as Date;
import 'types.dart' as Type;

main () {
  Numbers.run();
  Strings.run();
  StringConcat.run();
  StringsTriple.run();
  StringsAdjacent.run();
  StringsInterpolation.run();
  Booleans.run();
  HashMaps.run();
  HashPutIfAbsent.run();
  Lists.run();
  ListIterators.run();
  Set.run();
  Queue.run();
  Date.run();
  Type.run();
}
