library booleans_snippet;

import 'package:unittest/unittest.dart';

String _str1, _str2, _str3;

run() {
  group("[booleans]", (){
    setUp((){
      /* ------------------------- */
      var name, greeting;
      greeting = name ? "Howdy $name" : "Howdy";
      // "Howdy"
      _str1 = greeting;

	  
      /*** Name is still not true ***/
      name = "Bob";
      greeting = name ? "Howdy $name" : "Howdy";
      // "Howdy"
      _str2 = greeting;

	   
      greeting = (name != null) ? "Howdy $name" : "Howdy";
      // "Howdy Bob"
      _str3 = greeting;
      /* ------------------------- */
    });

    test('null is false', (){
      expect(_str1, equals("Howdy"));
    });

    test('string is false', (){
      expect(_str2, equals("Howdy"));
    });

    test('only booleans can be true', (){
      expect(_str3, equals("Howdy Bob"));
    });

  });
}
