library types_snippet;

import 'package:unittest/unittest.dart';
import 'dart:collection';
import '../annotations.dart';

String _str1, _str2, _str3;

run() {
  group("[types]", (){
    setUp((){
      /* ------------------------- */
      /* ------------------------- */
    });

    test('assign number to a variable previously assigned a string', (){
      expect(
        (){
          var muppet = 'Piggy';

          // Dart, like JavaScript, allows this, but come on!
          muppet = 42;
        },
        returnsNormally
      );
    });

    group('assign number to a variable declared as String', (){
      @IntentionalError('Demonstrating no compiler or run error')
      String muppet = 'Piggy';
      muppet = 42;
      /* What happens now????! */

      test(' -- is now a number', (){
        @IntentionalError('Runtime now treats this as a number')
        var _muppet_math =
          muppet + 17;
          // 59
        expect(
          _muppet_math,
          equals(59)
        );
      });
    });

    test('good manners with types', () {
      expect((){
          int i = 0;
          bool is_done = false;
          String muppet = 'Piggy';
          DateTime now = new DateTime.now();
        },
        returnsNormally
      );
    });

    test('types can contain types', (){
      expect((){
          HashMap<String,bool> is_awesome = {
            'Scooter': false,
            'Bert': true,
            'Ernie': false
          };

          List<int> primes = [1,2,3,5,7,11];
        },
        returnsNormally
      );
    });
  });
}
