library dates_snippet;

import 'package:unittest/unittest.dart';

DateTime _mar, _now, _apr, _may, _jul;
Duration _diff;

run() {
  group("[dates]", (){
    setUp((){
      /* ------------------------- */
      var mar = DateTime.parse('2013-03-01 14:31:12');
      // 2013-03-01 14:31:12.000
      var now = new DateTime.now();
      // 2012-12-31 23:59:59.149
      var apr = new DateTime(2013, 4, 1);
      // 2013-04-01 00:00:00.000
      var may = new DateTime(2013, 5, 1, 18, 18, 18);
      // 2013-05-01 18:18:18.000

      var jun = new DateTime(2013, 6, 1, 0, 0, 0, 0);
      var jul = new DateTime(2013, 7, 1, 0, 0, 0, 0);
      var diff = jul.difference(jun);
      diff.inDays; // => 30
      _diff = diff;
      jul.add(new Duration(days: 15)); // => 2013-07-16
      /* ------------------------- */
      _mar = mar;
      _now = now;
      _apr = apr;
      _may = may;
      _jul = jul;
    });

    test('can make a date from a string', (){
      expect(_mar.toString(), equals('2013-03-01 14:31:12.000'));
    });

    test('can make a now date', (){
      var new_now = new DateTime.now();
      expect(new_now.difference(_now).inMinutes, isZero);
    });

    test('can make just a date', (){
      expect(_apr.toString(), equals('2013-04-01 00:00:00.000'));
    });

    test('can make a date / time', (){
      expect(_may.toString(), equals('2013-05-01 18:18:18.000'));
    });

    test('can calculate differences', (){
      expect(_diff.inDays, equals(30));
    });

    test('can add N number of a days to a date', (){
      expect(_jul.add(new Duration(days: 15)), equals(new DateTime(2013, 7, 16)));
    });
  });
}
