import 'package:unittest/unittest.dart';
import 'package:unittest/html_enhanced_config.dart';
import "../web/scripts/HipsterCollection.dart";
main() {
  useHtmlEnhancedConfiguration();

  group('basic', (){
    test('arithmetic', (){
      expect(2 + 2, 5);
    });
  });
}
