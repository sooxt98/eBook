import 'package:unittest/unittest.dart';
import 'package:unittest/html_enhanced_config.dart';
import "../web/scripts/HipsterCollection.dart" ;
main() {
  useHtmlEnhancedConfiguration();
  // Tests go here!
}
