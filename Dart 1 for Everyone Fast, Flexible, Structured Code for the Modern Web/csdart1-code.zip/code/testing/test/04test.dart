import 'package:unittest/unittest.dart';
import 'package:unittest/html_enhanced_config.dart';
import "../web/scripts/HipsterCollection.dart";

main() {
  useHtmlEnhancedConfiguration();

  group("simple equality", (){
    test('HipsterCollection has multiple models', (){
      HipsterCollection it = new HipsterCollection();
      it.models = [{'id': 17}, {'id': 42}];
      expect(it.length, equals(2));
    });
  });

  group("exceptions", (){
    test('HipsterCollection fetch() fails without a url', () {
      HipsterCollection it = new HipsterCollection();
      expect(()=> it.fetch(), throwsNoSuchMethodError);
    });
  });

  group('HipsterCollection lookup', () {
    HipsterCollection it;
    setUp((){
      var model1 = {'id': 17},
          model2 = {'id': 42};

      it = new HipsterCollection();
      it.models = [model1, model2];
    });

    test('works by ID', () {
      print(it.models);
      expect(it[17], equals({'id': 17}));
      expect(it[17].values, equals([17]));
      expect(it[17].keys, equals(['id']));
    });

    test('is null when it does not hold ID', () {
      expect(it[1], isNull);
    });
  });
}
