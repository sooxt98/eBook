#import('lib/unittest/unittest_dartest.dart');
#import('lib/dartest/dartest.dart');

#import("../public/scripts/HipsterCollection.dart");
#import("../public/scripts/HipsterSync.dart");

main() {
  test('HipsterCollection has multiple models', (){
    HipsterCollection it = new HipsterCollection();
    it.models = [{'id': 17}, {'id': 42}];

    Expect.equals(2, it.length);
  });

  test('HipsterCollection fetch() fails without a url', () {
    HipsterCollection it = new HipsterCollection();
    Expect.throws(() {it.fetch();});
  });

  group('HipsterCollection lookup', () {
    var model1 = {'id': 17},
        model2 = {'id': 42};

    HipsterCollection it = new HipsterCollection();
    it.models = [model1, model2];

    test('works by ID', () {
      Expect.listEquals([17], it[17].getValues());
      Expect.listEquals(['id'], it[17].getKeys());
      Expect.equals(model1, it[17]);
    });

    test('is null when it does not hold ID', () {
      Expect.isNull(it[1]);
    });
  });


  asyncTest('HipsterCollection add dispatches insert events', 1, () {
    // don't care about data sync in this case
    noOpSync(method, model, [options]) {}
    HipsterSync.sync = noOpSync;

    HipsterCollection it = new HipsterCollection();

    it.
      on.
      insert.
      add((event) {
        callbackDone();
      });

    it.add({'id': 42});
  });

  new DARTest().run();
}
