import 'package:unittest/unittest.dart';
import 'package:unittest/html_enhanced_config.dart';
import "../web/scripts/HipsterCollection.dart" ;
import "../web/scripts/HipsterSync.dart" ;
main() {
  useHtmlEnhancedConfiguration();

  group('HipsterCollection', (){
    test('HipsterCollection fetch() fails without a url', () {
      var it = new HipsterCollection();
      expect(()=> it.fetch(), throws);
    });
  });


  group('HipsterCollection lookup', () {
    var model1 = {'id': 17},
        model2 = {'id': 42};

    HipsterCollection it = new HipsterCollection();
    it.models = [model1, model2];

    test('works by ID', () {
      expect(it[17], isNotNull);
      expect(it[17], isMap);
      expect(it[17].values, [17]);
      expect(it[17].keys, equals(['id']));
      expect(it[17], equals(model1));
    });

    test('is null when it does not hold ID', () {
      expect(it[1], isNull);
    });
  });


  group('Async', (){
    test('HipsterCollection add dispatches insert events', (){
      HipsterCollection it = new HipsterCollection();
      it.onAdd.listen(expectAsync((model) {
        expect(model, isNotNull);
      }));

      it.add({'id': 42});
    });
  });
}
