library hipster_collection;
import 'dart:html';
import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'HipsterModel.dart';
class HipsterCollection extends IterableBase {
  StreamController _onLoad = new StreamController.broadcast(),
                   _onAdd = new StreamController.broadcast();
  List models = [];

  HipsterModel modelMaker(attrs);
  String get url;

  // Be List-like
  Iterator get iterator => models.iterator;

  // Be Backbone like
  Stream get onLoad => _onLoad.stream;
  Stream get onAdd => _onAdd.stream;

  operator [](id)=>
    firstWhere((model)=> model['id'] == id, orElse: ()=> null);

  fetch() {
    var req = new HttpRequest();

    req.onLoad.listen(_handleOnLoad);
    req.open('get', url);
    req.send();
  }

  create(attrs) {
    var new_model = modelMaker(attrs);
    new_model.save(callback:(event) {
      this.add(new_model);
    });
  }

  add(model) {
    models.add(model);
    _onAdd.add(model);
  }

  _handleOnLoad(event) {
    var request = event.target,
        list = JSON.decode(request.responseText);

    list.forEach((attrs) {
      models.add(modelMaker(attrs));
    });

    _onLoad.add(this);
  }
}
