#!/bin/bash
#---
# Excerpted from "Dart 1 for Everyone",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material, 
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose. 
# Visit http://www.pragmaticprogrammer.com/titles/csdart1 for more book information.
#---

# Start the test server
packages/plummbur_kruk/start.sh

# Run a set of Dart Unit tests
results=$(content_shell --dump-render-tree index.html 2>&1)
echo -e "$results"

# Stop the server
packages/plummbur_kruk/stop.sh

# check to see if DumpRenderTree tests
# fails, since it always returns 0
if [[ "$results" == *"Some tests failed"* ]]
then
    exit 1
fi

# Static type analysis
echo
echo "Static type analysis..."

results=$(dartanalyzer test.dart 2>&1)
results_ignoring_ok_deprecations=$(
  echo "$results" | \
    grep -v "'query' is deprecated" | \
    grep -v "'queryAll' is deprecated" | \

    # Known / intentional errors:
    grep -v "code/primitives/types.dart, line 34" | \
    grep -v "code/primitives/types.dart, line 42" | \
    grep -v "code/varying_the_behavior/test/calling_methods_from_no_such_method.dart, line 20" | \
    grep -v "code/varying_the_behavior/test/calling_methods_from_no_such_method.dart, line 24" | \

    # Known / intentional unused imports:
    grep -v "your_first_dart_app/web/scripts/skel.dart, line 4" | \
    grep -v "your_first_dart_app/web/scripts/skel.dart, line 5" | \
    grep -v "libraries/prefixed_imports.dart, line 5" | \
    grep -v "classes/implements_multiple.dart, line 9" | \

    grep -v "hints found.$"
)
echo "$results_ignoring_ok_deprecations"


count=$(echo "$results_ignoring_ok_deprecations" | wc -l)
if [[ "$count" != "2" ]]
then
  exit 1
fi

echo
echo "Looks good!"
# TODO: grep TODOs
