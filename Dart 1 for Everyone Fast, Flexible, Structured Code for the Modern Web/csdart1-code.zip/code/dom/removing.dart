library removing_snippets;

import 'dart:html';
import 'package:unittest/unittest.dart';

run() {
  group("[removing]", (){
    var el = new DivElement();

    setUp((){
      document.body.nodes.add(el);
    });
    tearDown((){
      document.body.nodes.removeLast();
      el.innerHtml = '';
    });

    test('remove single element', (){
      el.append(new Element.html('''
        <div id="content"><div id="gallery"></div></div>
      '''));

      document.
        query('#content').
        query('#gallery').
        remove();

      expect(el.innerHtml, equals('<div id="content"></div>'));
    });





  });
}
