library finding_snippets;

import 'dart:html';
import 'package:unittest/unittest.dart';

run() {
  group("[finding]", (){
    var el = new DivElement();
    setUp((){
      document.body.nodes.add(el);
      el.innerHtml = """
        <h1>First Big Title</h1>
        <h2>First Small Title</h2>
        <h2>Second Small Title</h2>
        <h2>Third Small Title</h2>

        <h1>Second Big Title</h1>
        <ul id=people-list>
          <li>Bob</li>
          <li class=active>Sally</li>
          <li class=active>Lucy</li>
        </ul>
      """;
    });
    tearDown((){
      document.body.nodes.removeLast();
      el.innerHtml = '';
    });

    test('query single tag', (){
      var el =
        document.query('h1');             // => First <h1> in the document

      expect(el.innerHtml, equals('First Big Title'));
    });

    test('query single ID', (){
      var el =
        document.query('#people-list');   // => Element with id of 'people-list'

      expect(el.tagName, equals('UL'));
      expect(el.children.length, equals(3));
    });

    test('query single class', (){
      var el =
        document.query('.active');        // => First element with 'active' class

      expect(el.innerHtml, equals('Sally'));
    });

    test('query single class', (){
      var els =
        document.queryAll('h2');          // => All <h2> elements

      expect(els.length, equals(3));
      expect(els[2].innerHtml, equals('Third Small Title'));
    });

    test('scope queries to other queuries', (){
      var list = document.query('ul#people-list');
      var last_person = list.query(':last-child');
      last_person.innerHtml;
      // => 'Lucy'

      expect(last_person.innerHtml, equals('Lucy'));
    });

    test('scope chains', (){
      var last_person =
      document.
        query('ul#people-list').
        query(':last-child').
        innerHtml;
      // => 'Lucy'

      expect(last_person, equals('Lucy'));
    });

    test('iterating', (){
      document.
        query('ul#people-list').
        queryAll('li').
        forEach((li) {
          li.classes.add('highlight');
        });

      expect(document.queryAll('li').last.classes, contains('highlight'));
    });
  });
}
