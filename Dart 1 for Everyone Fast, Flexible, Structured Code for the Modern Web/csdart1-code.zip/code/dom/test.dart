library dom_test;

import 'finding.dart' as Finding;
import 'adding.dart' as Adding;
import 'removing.dart' as Removing;
import 'updating.dart' as Updating;

main () {
  Finding.run();
  Adding.run();
  Removing.run();
  Updating.run();
}
