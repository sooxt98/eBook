library adding_snippets;

import 'dart:html';
import 'package:unittest/unittest.dart';

run() {
  group("[adding]", (){
    var el = new DivElement();

    setUp((){
      document.body.nodes.add(el);
    });
    tearDown((){
      document.body.nodes.removeLast();
      el.innerHtml = '';
    });

    test('text setter', (){
      var gallery = new DivElement();
      gallery.text = 'Welcome to the Gallery';

      el.append(gallery);
      expect(el.innerHtml, equals('<div>Welcome to the Gallery</div>'));
    });

    test('html named constructor', (){
      var gallery = new Element.html('<div id="gallery">');

      el.append(gallery);
      expect(el.innerHtml, equals('<div id="gallery"></div>'));
    });

    test('create complex HTML', (){
      var gallery = new Element.html("""
        <div id="gallery">
          <ul>
            <li><img src="img01.png">
            <li><img src="img02.png">
            <li><img src="img03.png">
            <!-- ... -->
          </ul>
        </div>""");

      el.append(gallery);
      expect(el.query('ul').children.length, equals(3));
    });

    test('create complex HTML', (){
      gallery(title, photographer) {
        return new Element.html("""
          <div id="gallery">
            <h2>${title}</h2>
            <ul>
              <li><img src="img01.png"/>
              <li><img src="img02.png"/>
              <li><img src="img03.png"/>
              <!-- ... -->
            </ul>
            <h3 class="footer">
              Photos by: ${photographer}
            </h3>
          </div>""");
      }

      el.append(gallery('Awesome Gallery', 'Bob'));
      expect(el.query('ul').children.length, equals(3));
      expect(el.query('h2').innerHtml, equals('Awesome Gallery'));
      expect(el.query('.footer').innerHtml, contains('Photos by: Bob'));
    });

    test('append', (){
      el.append(new Element.html('<div id="content">'));

      var gallery = new Element.html('<div id="gallery">');
      document.
        query('#content').
        append(gallery);

      expect(el.query('div').innerHtml, equals('<div id="gallery"></div>'));
    });

    test('insert adjacent', (){
      el.append(new Element.html('<div id="content"><p>hi!</p></div>'));

      var gallery = new Element.html('<div id="gallery">');
      document.
        query('#content').
        insertAdjacentElement('afterBegin', gallery);

      expect(
        el.query('div').innerHtml,
        equals('<div id="gallery"></div><p>hi!</p>'));
    });


  });
}
