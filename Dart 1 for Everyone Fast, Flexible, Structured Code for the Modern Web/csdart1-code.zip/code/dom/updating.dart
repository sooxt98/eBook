library updating_snippets;

import 'dart:html';
import 'package:unittest/unittest.dart';

run() {
  group("[updating]", (){
    var el = new DivElement();

    setUp((){
      document.body.nodes.add(el);
    });
    tearDown((){
      document.body.nodes.removeLast();
      el.innerHtml = '';
    });

    test('adding and removing a class', (){
      el.append(new Element.html('''
        <blockquote class="subdued"></blockquote>
      '''));

      document.
        query('blockquote').
        classes.
        remove('subdued');

      document.
        query('blockquote').
        classes.
        add('highlighted');

      expect(el.query('blockquote').classes, contains('highlighted'));
      expect(el.query('blockquote').classes, isNot(contains('subdued')));
    });

    test('updating content', (){
      el.append(new Element.html('''
        <blockquote></blockquote>
      '''));

      document.
        query('blockquote').
        innerHtml = 'Four score and <u>seven</u> years ago...';

      expect(el.query('blockquote').innerHtml, equals('Four score and <u>seven</u> years ago...'));
    });

    test('method cascade', (){
      el.append(new Element.html('''
        <blockquote class="subdued"></blockquote>
      '''));

      document.
        query('blockquote').
        classes
          ..remove('subdued')
          ..add('highlighted');

      expect(el.query('blockquote').classes, contains('highlighted'));
      expect(el.query('blockquote').classes, isNot(contains('subdued')));
    });


  });
}
