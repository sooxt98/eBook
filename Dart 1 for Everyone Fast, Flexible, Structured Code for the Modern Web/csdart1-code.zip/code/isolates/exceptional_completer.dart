library exceptional_completer;

import 'dart:async';

main() {
  var completer = new Completer();
  completer.
    future.
    catchError((e) {
      print("Handled: $e");
      return true;
    });
  var exception = new Exception("Too awesome");
  completer.completeError(exception);
}

// For testing. Comment out to run this code file directly...
var cb = (_){};
print(msg) => cb(msg);
