library isolate_snippet;

final List<String> dayNames = [
  'Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat', 'Sun'
];

dayOfDoom(year) {
  var march1 = new DateTime(year, 3, 1, 0, 0, 0, 0),
      oneDay = new Duration(days:1),
      date = march1.subtract(oneDay);

  return dayNames[date.weekday - 1];
}

main(List<String> args, SendPort replyTo) {
  var year = int.parse(args[0]);
  var doomsday = dayOfDoom(year);
  replyTo.send(doomsday);
}
