library simple_completer;

import 'dart:async';

main() {
  var completer = new Completer();
  var future = completer.future;
  future.then((message) {
    print("Future completed with message: $message");
  });
  completer.complete("foo");
}

var cb;
print(msg) => cb(msg);
