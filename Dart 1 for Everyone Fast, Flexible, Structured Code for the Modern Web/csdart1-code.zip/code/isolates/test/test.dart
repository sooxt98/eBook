import 'completer.dart' as SimpleCompleter;
import 'isolates.dart' as Isolates;

main () {
  SimpleCompleter.run();
  Isolates.run();
}
