library isolate_test;

import 'package:unittest/unittest.dart';

import 'dart:isolate';
import 'dart:async';

var _printStreamController = new StreamController();
var _printStream = _printStreamController.stream;

print(val) {
  _printStreamController.add(val);
}

run() {
  group("[isolates]", (){
    test('can send back replies', (){
      var res = new ReceivePort();
      var sender = Isolate.spawnUri(
        Uri.parse('isolates/main.dart'),
        ['2014'],
        res.sendPort
      );
      sender.
        then((_)=> res.first).
        then((message) {
          print('Doom in 2014 falls on a ${message}.');
        });

     _printStream.
       listen(expectAsync((message) {
         expect(
           message,
           'Doom in 2014 falls on a Fri.'
         );
       }));
    });
  });
}
