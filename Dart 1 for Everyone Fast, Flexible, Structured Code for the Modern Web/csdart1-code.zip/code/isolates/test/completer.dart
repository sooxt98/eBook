library completer_test;

import 'package:unittest/unittest.dart';
import 'dart:async';

import '../simple_completer.dart' as Simple;
import '../exceptional_completer.dart' as Exceptional;

run() {
  group("[simple completers]", (){
    test('can complete in the future', (){
      Simple.cb = expectAsync((msg){
        expect(msg, equals("Future completed with message: foo"));
      });
      Simple.main();
    });

    test('can cause future exceptions', (){
      Exceptional.cb = expectAsync((msg){
        expect(msg, equals("Handled: Exception: Too awesome"));
      });
      Exceptional.main();
    });

    test('can complete once', (){
      var completer = new Completer();
      var future = completer.future;

      expect(future, completion("foo"));

      completer.complete("foo");
    });

    test('cannot complete a second time', (){
      var completer = new Completer();
      var future = completer.future;

      expect(
        (){
          completer.complete("once");
          completer.complete("twice");
        },
        throwsStateError
      );
    });

  });
}
