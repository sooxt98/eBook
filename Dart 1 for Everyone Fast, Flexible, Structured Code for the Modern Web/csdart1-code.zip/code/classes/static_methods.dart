library static_methods_snippet;

import 'package:unittest/unittest.dart';

class Planet {
  static List rocky_planets = const [
    'Mercury', 'Venus', 'Earth', 'Mars'
  ];
  static List gas_giants = const [
    'Jupiter', 'Saturn', 'Uranus', 'Neptune'
  ];
  static List get known {
    var all = [];
    all.addAll(rocky_planets);
    all.addAll(gas_giants);
    return all;
  }
}

class ComicsCollection {}

run() {
  group("[static_methods]", (){
    test('calling methods', (){
      var planets =
        Planet.known
        // => ['Mercury', 'Venus', 'Earth', 'Mars',
        //     'Jupiter', 'Saturn', 'Uranus', 'Neptune' ]
        ;

      expect(
        planets,
        contains('Neptune')
      );
    });
  });
}
