library mixinx_snippets;

import 'package:unittest/unittest.dart';

class Person {
  String name;
  Person(this.name);
}

class Animal {
  String name;
  Animal(this.name);
}

abstract class Greeting {
  String get name;
  greet() => "Howdy $name!";
}


class Friend extends Person with Greeting {
  Friend(name): super(name);
}

class Pet extends Animal with Greeting {
  Pet(name): super(name);
}

run () {
  group('[mixins]', (){
    test('call mixin from one class', (){
      var say_hi = new Friend('Alice').greet();
      // => 'Howdy Alice!'

      expect(say_hi , equals('Howdy Alice!'));
    });

    test('call mixin from one class', (){
      var say_hi = new Pet('Snoopy').greet();
      // => 'Howdy Snoopy!'

      expect(say_hi , equals('Howdy Snoopy!'));
    });
  });
}
