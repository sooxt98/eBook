library generative_constructor_snippet;

import 'package:unittest/unittest.dart';

class ComicsCollection {
  List<ComicModel> models;
  // Our constructor
  ComicsCollection() {
    models = [];
  }
}

class ComicModel {
  ComicModel() {
    attributes = {};
  }

  var attributes;
  // ...
}

run() {
  group("[generative_constructor]", (){
    test('can construct', (){
      var comics = new ComicsCollection();
      expect(
        comics.models.length,
        equals(0)
      );
    });

  });
}
