library methods_snippet;

import 'package:unittest/unittest.dart';

class Element {
  var innerHtml;
}

template(obj) => "foo";

var el = new Element();
var collection = {};

class ComicsView {
  // ...
  render() {
    el.innerHtml = template(collection);
  }
}

class ComicsCollection {}

run() {
  group("[methods]", (){
    test('methods are named functions in a class', (){
      var view = new ComicsView();
      view.render();
      expect(
        el.innerHtml,
        equals("foo")
      );
    });
  });
}
