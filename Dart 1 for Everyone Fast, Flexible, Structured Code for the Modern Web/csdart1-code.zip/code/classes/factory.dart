library factory_snippet;

import 'package:unittest/unittest.dart';

// TODO: rewrite factories because this is no longer valid
class PrettyName {
  PrettyName(name);
  // factory PrettyName(name) {
  //   return "Pretty $name";
  // }
}

run() {
  group("[factory]", (){
    skip_test('can factory other stuff besides the container class', (){
      var pretty_name =
      new PrettyName("Bob");
      // => "Pretty Bob"

      expect(
        pretty_name,
        equals("Pretty Bob")
      );
    });
  });
}
