library constructor_optional_this_snippet;

import 'package:unittest/unittest.dart';

class ComicsView {
  ComicsCollection collection;
  ComicModel model;
  Element el;

  ComicsView({this.el, this.model, this.collection}) {
    if (this.el == null) {
      this.el = new DivElement();
    }
  }
}

class ComicsCollection {}
class ComicModel {}
class Element {}
class DivElement extends Element {}

class ModelEvents {}

run() {
  group("[optional_this_param]", (){
    test('can construct with optional params', (){
      var comic_book = new ComicModel();
      var view = new ComicsView(model: comic_book);
      expect(view.el, isNotNull);
      expect(view.model, equals(comic_book));
    });

  });
}
