library implements_multiple_snippet;

import 'package:unittest/unittest.dart';

class ComicsCollection implements Iterable, EventTarget {
  // Iterable methods
  void forEach(fn) { /* ... */ }
  int get length { /* ... */ }
  // EventTarget
  Events get on => _on;

  var models = ['Sandman', 'V for Vendetta'];
  var _on = new Events();

  get iterator => models.iterator;

  bool get isEmpty => models.isEmpty;
  bool get isNotEmpty => models.isNotEmpty;
  map(fn) => models.map(fn);
  contains(element) => models.contains(element);
  reduce(fn) => models.reduce(fn);
  every(fn) => models.every(fn);
  any(fn) => models.any(fn);
  skip(n) => models.skip(n);
  toSet() => models.toSet();
  get last => models.last;
  get single => models.single;
  singleWhere(fn) => models.singleWhere(fn);
  fold(initial, fn) => models.fold(initial, fn);
  take(n) => models.take(n);
  takeWhile(fn) => models.takeWhile(fn);
  join([sep=""]) => models.join(sep);
  where(fn) => models.where(fn);
  elementAt(n) => models.elementAt(n);
  lastWhere(fn, {orElse()}) => models.lastWhere(fn, orElse: orElse);
  toList({growable: true}) => models;
  skipWhile(fn) => models.skipWhile(fn);
  expand(fn) => models.expand(fn);
  firstWhere(fn, {orElse()}) => models.firstWhere(fn, orElse: orElse);
  get first => models.first;

  // ...
}

class EventTarget {}
class Events {}

run() {
  group("[implements_multiple]", (){
    test('implements the interface', (){
      var comics = new ComicsCollection();
      expect(
        comics.isEmpty,
        isFalse
      );
    });

  });
}
