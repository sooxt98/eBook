library private_snippet;

import 'package:unittest/unittest.dart';
import '../annotations.dart';

class ComicsView {
  // Private because it starts with underscore
  ComicsCollection _collection;
  ComicsCollection get collection {
    // possibly restrict access here...
    return _collection;
  }
}

class ComicsCollection {}

run() {
  group("[private]", (){
    test('has no setter', (){
      var view = new ComicsView();

      assign_non_existent_setter() {
        @IntentionalError('Demonstrate non-existent setter call')
        var collection = view.collection = new ComicsCollection();
      };

      expect(
        assign_non_existent_setter,
        throwsNoSuchMethodError
      );
    });

    test('getter works only if explicitly defined', (){
      var view = new ComicsView();
      expect(
        ()=> view.collection,
        returnsNormally
      );
    });
  });
}
