library cascades_snippet;

import 'package:unittest/unittest.dart';

class Element {
  var style = new Style();
}

class Style {
  var opacity, position, top, left, backgroundColor, padding, borderRadius,
    zIndex, transition;
}

run() {
  group("[cascades]", (){
    test('are the same as calling the same method twice', (){
      var list1 = [];
      list1.add(17);
      list1.add(42);

      var list2 = [];
      list2
        ..add(17)
        ..add(42);

      expect(list2, equals(list1));
    });

    test('ugly, old-fashioned setters', () {
      var el = new Element();
      el.style.opacity = '0';
      el.style.position = 'absolute';
      el.style.top = '80px';
      el.style.left = '0px';
      el.style.zIndex = '1001';
      el.style.transition = 'opacity 1s ease-in-out';
      el.style.opacity = '1';
      expect(el.style.top, equals('80px'));
    });

    test('work with setters', (){
      var el = new Element();
      el.style
        ..opacity = '0'
        ..position = 'absolute'
        ..top = '80px'
        ..left = '0px'
        ..zIndex = '1001'
        ..transition = 'opacity 1s ease-in-out'
        ..opacity = '1';
      expect(el.style.top, equals('80px'));
    });

  });
}
