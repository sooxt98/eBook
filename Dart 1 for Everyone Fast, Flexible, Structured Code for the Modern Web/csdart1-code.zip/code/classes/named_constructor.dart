library named_constructor_snippet;

import 'package:unittest/unittest.dart';

class ComicsCollection {
  List<ComicModel> models = [];
  ComicsCollection() {
    // "Normal" constructor here
  }

  ComicsCollection.fromCollection(collection) {
    models = collection.map(
      (attr) => new ComicModel(attr)
    );
  }
}

class ComicModel {
  var attributes;
  ComicModel(this.attributes);
}

run() {
  group("[named_constructor]", (){
    test('can construct', (){
      var comics = new ComicsCollection.fromCollection([
        {'id': 1, 'title': 'V for Vendetta', /* ... */ },
        {'id': 2, 'title': 'Superman', /* ... */ },
        {'id': 3, 'title': 'Sandman', /* ... */ }
      ]);
      expect(
        comics.models.length,
        equals(3)
      );
    });

  });
}
