library constructor_this_param_snippet;

import 'package:unittest/unittest.dart';

class ComicBook {
  Map attributes;
  ComicBook(this.attributes);
}

run() {
  group("[constructor_this_param]", (){
    test('can construct', (){
      var comic = new ComicBook({'title': 'Sandman'});
      expect(
        comic.attributes['title'],
        equals('Sandman')
      );
    });

  });
}
