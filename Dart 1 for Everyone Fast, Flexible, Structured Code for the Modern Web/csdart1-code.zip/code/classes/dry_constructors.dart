library dry_constructor_snippet;

import 'package:unittest/unittest.dart';

class ComicBook {
  Map attributes;
  ComicBook(attrs) {
    this.attributes = attrs;
  }
  // Redirect from the `named` constructor to the all-purpose constructor
  ComicBook.named(name): this({'title': name});
}

class AwesomeComicBook extends ComicBook {
  AwesomeComicBook(attrs): super(attrs);
  AwesomeComicBook.byNeilGaiman(): this({'author': 'Neil Gaiman'});
  AwesomeComicBook.byAlanMoore(): this({'author': 'Alan Moore'});
}

run() {
  group("[dry_constructor]", (){
    test('can construct the same way', (){
      var c1 = new ComicBook({'title': 'Sandman'});
      var c2 = new ComicBook.named('Sandman');
      expect(
        c1.attributes['title'],
        equals(c2.attributes['title'])
      );
    });

    test('redirecting in subclass', (){
      var ng = new AwesomeComicBook.byNeilGaiman();
      var am = new AwesomeComicBook.byAlanMoore();
      expect(ng.attributes['author'], equals('Neil Gaiman'));
      expect(am.attributes['author'], equals('Alan Moore'));
    });

  });
}
