library lazy_ivars_snippet;

import 'package:unittest/unittest.dart';

class ComicsCollection {
  List<ComicModel> models = [];
}

class ComicModel {}

run() {
  group("[lazy_ivars]", (){
    test('can construct', (){
      var comics = new ComicsCollection();
      expect(
        comics.models.length,
        equals(0)
      );
    });

  });
}
