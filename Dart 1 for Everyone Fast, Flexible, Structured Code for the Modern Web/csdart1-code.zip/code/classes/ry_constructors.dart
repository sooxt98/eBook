library ry_constructor_snippet;

import 'package:unittest/unittest.dart';

class ComicBook {
  Map attributes;
  ComicBook(attrs) {
    this.attributes = attrs;
  }
  ComicBook.named(name) {
    this.attributes = {'title': name};
  }
}

run() {
  group("[non_dry_constructor]", (){
    test('can construct the same way', (){
      var c1 = new ComicBook({'title': 'Sandman'});
      var c2 = new ComicBook.named('Sandman');
      expect(
        c1.attributes['title'],
        equals(c2.attributes['title'])
      );
    });

  });
}
