library method_type_snippet;

import 'package:unittest/unittest.dart';

class Element {
  var innerHtml;
}

template(obj) => "foo";

var el = new Element();
var collection = {};

class ComicsView {
  void render() {
    el.innerHtml = template(collection);
  }
}

class ComicsCollection {}

run() {
  group("[method_type]", (){
    test('be a good citizen with method types', (){
      var view = new ComicsView();
      view.render();
      expect(
        el.innerHtml,
        equals("foo")
      );
    });
  });
}
