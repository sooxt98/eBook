library getter_methods_snippet;

import 'package:unittest/unittest.dart';

class ComicsCollection {
  String get url => '/comics';
}

run() {
  group("[getter_methods]", (){
    test('behave like properties', (){
      var comics_collection = new ComicsCollection();

      var url =
      // No parens required!
      comics_collection.url;      // => '/comics'
      expect(
        url,
        equals('/comics')
      );
    });
  });
}
