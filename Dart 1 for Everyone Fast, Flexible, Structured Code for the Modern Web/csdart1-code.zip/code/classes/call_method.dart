library call_operator_snippet;

import 'package:unittest/unittest.dart';

class ComicModel {
  call() {
    save();
  }
  save() {
    // do save things here...
  }
}

run() {
  group("[call_operator]", (){
    test('can masquerade as a function', (){
      var comic = new ComicModel();

      comic();

      expect(comic, returnsNormally);
    });
  });
}
