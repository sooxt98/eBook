library static_and_instance_methods_snippet;

import 'package:unittest/unittest.dart';

class Planet {
  /* START:asdf
  // ...
  static List get known { ... }
  END:asdf */
  String name;
  Planet(this.name);
  bool get isRealPlanet =>
    known.any((p) => p == this.name);

  static List rocky_planets = const [
    'Mercury', 'Venus', 'Earth', 'Mars'
  ];

  static List gas_giants = const [
    'Jupiter', 'Saturn', 'Uranus', 'Neptune'
  ];

  static List get known {
    var all = [];
    all.addAll(rocky_planets);
    all.addAll(gas_giants);
    return all;
  }
}

class ComicsCollection {}

run() {
  group("[static_and_instance_methods]", (){
    var _neptune_is_real, _pluto_is_real;

    setUp((){
      var neptune = new Planet('Neptune');
      var pluto = new Planet('Pluto');

      _neptune_is_real =
        neptune.isRealPlanet      // => true
        ;

      _pluto_is_real =
        pluto.isRealPlanet        // => false
        ;
    });

    test('calling methods', (){
      expect(_neptune_is_real, isTrue);
      expect(_pluto_is_real, isFalse);
    });
  });
}
