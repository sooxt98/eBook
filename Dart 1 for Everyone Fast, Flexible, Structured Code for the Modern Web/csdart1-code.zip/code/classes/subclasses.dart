library subclasses_snippet;

import 'package:unittest/unittest.dart';

class Comics extends HipsterCollection {
  String get url => '/comics';
  HipsterModel modelMaker(attrs) => new ComicBook(attrs);
}

abstract class HipsterCollection {
  String get url;
  HipsterModel modelMaker(attrs);
}

class ComicBook extends HipsterModel {
  var attributes;
  ComicBook(this.attributes);
}

class HipsterModel {}


run() {
  group("[subclasses]", (){
    test('still works like superclass', (){
      var comics = new Comics();
      expect(
        comics.url,
        equals('/comics')
      );
    });

  });
}
