library basics_snippet;

import 'package:unittest/unittest.dart';

class Element {}
class ComicModel {}

class ComicsCollection {
  // describe class operations here...
}

class ComicsView {
  ComicsCollection collection;
  ComicModel model;
  Element el;
  // ...
}

run() {
  group("[basics]", (){
    test('instantiation', (){
      var object = new ComicsCollection();
      expect(object, isNotNull);
    });

    test('ivar getter', (){
      var comics_view = new ComicsView();
      comics_view.collection;
      // => instance of ComicsCollection
      expect(()=>comics_view.collection, returnsNormally);
    });

    test('ivar setter', (){
      var new_collection = ['foo', 'bar'];
      var comics_view = new ComicsView();
      comics_view.collection = new_collection;
      expect(comics_view.collection, equals(['foo', 'bar']));
    });
  });
}
