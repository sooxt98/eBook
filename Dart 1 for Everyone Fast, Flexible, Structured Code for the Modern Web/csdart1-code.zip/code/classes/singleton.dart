library singleton_snippet;

import 'package:unittest/unittest.dart';

class Highlander {
  static Highlander the_one;
  String name;

  factory Highlander(name) {
    if (the_one == null) {
      the_one = new Highlander._internal(name);
    }

    return the_one;
  }

  // private, named constructor
  Highlander._internal(this.name);
}

run() {
  group("[singleton]", (){
    test('there is only one', (){
      var highlander = new Highlander('Connor MacLeod');
      var another = new Highlander('Kurgan');
      highlander.name;
      // => 'Connor MacLeod'
      // Nice try Kurgan...
      another.name;
      // => 'Connor MacLeod'

      expect(
        highlander.name,
        equals(another.name)
      );
    });
  });
}
