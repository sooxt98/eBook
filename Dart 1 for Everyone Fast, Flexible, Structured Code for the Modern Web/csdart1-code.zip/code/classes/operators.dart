library operators_snippet;

import 'package:unittest/unittest.dart';

class ComicModel {
  Map attributes;
  operator [](attr) => attributes[attr];
}

class OperatorHell {
  operator ==(v) => true;
  operator <(v) => true;
  operator >(v) => true;
  operator <=(v) => true;
  operator >=(v) => true;
  operator -(v) => true;
  operator +(v) => true;
  operator /(v) => true;
  operator ~/(v) => true;
  operator *(v) => true;
  operator %(v) => true;
  operator |(v) => true;
  operator ^(v) => true;
  operator &(v) => true;
  operator <<(v) => true;
  operator >>(v) => true;
  void operator []=(k, v) {}
  operator [](v) => true;
  operator ~() => true;
}

run() {
  group("[operators]", (){
    test('objects can override operators', (){
      var comic = new ComicModel();

      comic.attributes = {'title': "V for Vendetta"};

      var lookup_value =
      comic['title'] // => "V for Vendetta"
      ;

      expect(lookup_value, equals("V for Vendetta"));
    });

    test('all operators', (){
      var hell = new OperatorHell();
      expect(hell == 42, isTrue);
      expect(hell < 42, isTrue);
      expect(hell > 42, isTrue);
      expect(hell <= 42, isTrue);
      expect(hell >= 42, isTrue);
      expect(hell + 42, isTrue);
      expect(hell - 42, isTrue);
      expect(hell / 42, isTrue);
      expect(hell * 42, isTrue);
      expect(hell % 42, isTrue);
      expect(hell | 42, isTrue);
      expect(hell ^ 42, isTrue);
      expect(hell & 42, isTrue);
      expect(hell << 42, isTrue);
      expect(hell >> 42, isTrue);
      expect(() => hell[42]=42, returnsNormally);
      expect(hell[42], isTrue);
      expect(~hell, isTrue);
    });
  });
}
