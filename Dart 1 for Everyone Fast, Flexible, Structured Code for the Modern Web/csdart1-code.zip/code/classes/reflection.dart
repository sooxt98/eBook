library reflection_snippet;

import 'dart:mirrors';
import 'package:unittest/unittest.dart';

class Cookie {
  int number_of_chips;
  Cookie({this.number_of_chips:0});
}

main() {
  group('[reflection]', (){
    InstanceMirror im;
    Cookie cookie;
    setUp((){
      cookie = new Cookie(number_of_chips: 42);
      im = reflect(cookie);
    });

    test('getField returns a future', (){
      var type = im.getField('number_of_chips').runtimeType;
      expect(type.toString(), contains('Future'));
    });

    test('getField can find the original value', (){
      im.getField('number_of_chips').then((v){
        expect(v.reflectee, equals(42));
      });
    });

    test('reflectee in same isolate', (){
      expect(im.hasReflectee, isTrue);
      expect(im.reflectee.number_of_chips, equals(42));
    });

    test('reflectee refers to the same object as the original', (){
      expect(identical(cookie, im.reflectee), isTrue);
    });

    test('list instance methods', (){
      var cm = im.type,
          methods = cm.methods;
      expect(methods, equals({}));
    });

    test('list instance getters', (){
      var cm = im.type,
          getters = cm.getters;
      expect(getters, equals({}));
    });

    test('list instance members', (){
      var cm = im.type,
          members = cm.members;
      expect(members.values.map((v)=>v.simpleName), equals(['number_of_chips']));
    });
  });

}
