library annotations_snippet;

import 'package:unittest/unittest.dart';
import 'package:meta/meta.dart';

@BugFix(number: 42, comment: "Typo")
@BugFix(number: 45, author: "Chris", comment: "Typo")
class Cookie {
  int number_of_chips;
  Cookie({this.number_of_chips:42});

  @deprecated
  void mix_it() {
    print("Mixing ingredients and ${number_of_chips} chips.");
  }
}

class ThinMint extends Cookie {
  ThinMint(): super(number_of_chips: 0);
}

main() {
  @FixMe("Moar better code")
  var cookie = new Cookie();
  print("cookie has ${cookie.number_of_chips} chips");

  cookie.mix_it();

  print("\n*** Thin Mint time!");
  var thin_mint = new ThinMint();
  thin_mint.mix_it();
}

class BugFix {
  final int number;
  final String author;
  final String comment;
  const BugFix({this.number, this.author, this.comment});
}

class FixMe {
  final String note, author, date;
  const FixMe(this.note, {this.author, this.date});
}
