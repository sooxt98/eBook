library constructor_simple_params_snippet;

import 'package:unittest/unittest.dart';

class ComicBook {
  Map attributes;
  ComicBook(attributes) {
    this.attributes = attributes;
  }
}

run() {
  group("[constructor_simple_params]", (){
    test('can construct', (){
      var comic = new ComicBook({'title': 'Sandman'});
      expect(
        comic.attributes['title'],
        equals('Sandman')
      );
    });

  });
}
