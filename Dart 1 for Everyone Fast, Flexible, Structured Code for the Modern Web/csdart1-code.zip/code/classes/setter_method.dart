library setter_methods_snippet;

import 'package:unittest/unittest.dart';

class ComicsCollection {
  String _url;
  void set url(new_url) {
    _url = new_url;
  }
  String get url => _url;
}

run() {
  group("[setter_methods]", (){
    test('behave like properties', (){
      var comics_collection = new ComicsCollection();
      var shiny_new_url = '/comics';

      comics_collection.url = shiny_new_url;

      expect(
        comics_collection.url,
        equals(shiny_new_url)
      );
    });
  });
}
