library no_such_method_snippet;

import 'package:unittest/unittest.dart';

@proxy
class ComicModel {
  // ...
  noSuchMethod(args) {
    if (args.memberName != new Symbol('save')) {
      throw new NoSuchMethodError(
        this,
        args.memberName,
        args.positionalArguments,
        args.namedArguments
      );
    }
    // Do save operations here...
  }
}

class ComicsCollection {}

run() {
  group("[no_such_method]", (){
    test('save with noSuchMethod', (){
      var model = new ComicModel();
      expect(
        ()=> model.save(),
        returnsNormally
      );
    });

    test('when there really is no such method', (){
      var model = new ComicModel();
      expect(
        ()=> model.foo(),
        throwsNoSuchMethodError
      );
    });
  });
}
