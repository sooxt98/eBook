class Cookie {
  var number_of_chips;
  Cookie({this.number_of_chips});
}

class PerfectCookie {
  final number_of_chips;
  const PerfectCookie({this.number_of_chips});
}

main() {
  var c1 = new Cookie(number_of_chips: 12),
      c2 = new Cookie(number_of_chips: 12);
  var pc1 = const PerfectCookie(number_of_chips: 42),
      pc2 = const PerfectCookie(number_of_chips: 42),
      pc3 = new PerfectCookie(number_of_chips: 42);

  print("c1 and c2 identical? ${identical(c1, c2)}");
  print("pc1 and pc2 identical? ${identical(pc1, pc2)}");
  print("pc1 and pc3 identical? ${identical(pc1, pc3)}");

  const pc42 = const PerfectCookie(number_of_chips: 42),
      pc84 = const PerfectCookie(number_of_chips: 84),
      pc99 = const PerfectCookie(number_of_chips: 99);

  var cookie = pc1;
  switch(cookie) {
  case(pc42):
    print(42);
    break;
  case(pc84):
    print(84);
    break;
  case(pc3):
    print(84);
    break;
  }


  // cookie.number_of_chips = 13;
  // //  perfect_cookie.number_of_chips = 43;

  // print("An ordinary cookie has ${cookie.number_of_chips} chips");
  // print("The perfect cookie has ${perfect_cookie.number_of_chips} chips");
}
