//#import('dart:dom', prefix: 'dom');
#import('dart:html');

main() {
  var request = window.webkitIndexedDB.open('asdf');

  request.
    $dom_addEventListener('success', (event) {
      print("Niiice! Something good happened: ${event.target}");

      IDBDatabase db = event.target;
      print("the db is: ${request.result}");
    });

  // request.
  //   addEventListener('error', (event) {
  //     print("Whoa! Something bad happened: ${event}");
  //   });

  // print(request);
}
