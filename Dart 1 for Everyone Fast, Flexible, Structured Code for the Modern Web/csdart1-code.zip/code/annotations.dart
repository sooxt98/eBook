library annotations;

/// Use when intentionally causing an error.
///
///     @IntentionalError('Demo when semi-colon is omitted')
///     var foo = "bar"
class IntentionalError {
  final String note;
  const IntentionalError([this.note]);
}

/// Identify code in need of fixing.
///
///     @FixMe('Better naming')
///     var foo = "bar";
///
///     class Cookie {
///       @FixMe('Use hash rocket', date: '2013-01-01')
///       baking_time {
///         return 10;
///       }
///     }
class FixMe {
  final String note, author, date;
  const FixMe(this.note, {this.author, this.date});
}
